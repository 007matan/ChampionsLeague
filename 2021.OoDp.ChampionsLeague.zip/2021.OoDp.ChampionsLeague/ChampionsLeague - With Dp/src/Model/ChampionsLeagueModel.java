package Model;

import java.util.InputMismatchException;

import Exceptions.RegistrationException;

public class ChampionsLeagueModel {
	private static ChampionShip theChampionship;
	//71070 --- New --- 2021 --- New (Memento)
	//Start:
	private static MementoChampionshipADDPerson currMemento;
	//End. 
	
	public ChampionsLeagueModel() {
		//71070 --- New --- 2021 --- New (Singelton)
		//Start:
		theChampionship = ChampionShip.instanse;
		//End
	}
	
	public int addParticipant(String name, int id) throws InputMismatchException, Exception {
		//71070 --- New --- 2021 --- New (Memento)
		//Start:
		currMemento = theChampionship.addPerson(name, id);
		//End
		return theChampionship.getParticipantsList().size();
	}
	//71070 --- New --- 2021 --- New (Memento)
	//Start:
	public void undoParticipant() {
		theChampionship.UndoAddPerson(currMemento);
	}
	//End
	
	//71070 --- New --- 2021 --- New 
	//Start:
	public AuthorizedPress addAutorizedPress(String mediaName, String contactPersonName, String contactPhoneNumber, String name, int id) throws InputMismatchException, RegistrationException, Exception {
		return theChampionship.addAutorizedPress(mediaName, contactPersonName, contactPhoneNumber, name, id);
	}
	//End..
	
	public void startTheTour(String game) {
		theChampionship.startTheTour(game);
	}

	public static ChampionShip getTheChampionship() {
		return theChampionship;
	}
	

}
