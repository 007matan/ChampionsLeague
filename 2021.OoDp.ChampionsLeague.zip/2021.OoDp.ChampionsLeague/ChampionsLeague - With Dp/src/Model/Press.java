//71070 --- New --- 2021 --- New (Proxy, Facade)
//Start:
package Model;

import java.util.ArrayList;
import java.util.InputMismatchException;

import Exceptions.RegistrationException;
import Inteface.Authorizable;


public class Press implements Authorizable {
	protected MediaCenter mediaCenter;
	protected Person person;
	
	protected FlyWeightMediaCenter mediaCenterDIST;
	
	public Press(MediaCenter mediaCenter, Person person)
	{
		this.mediaCenter = mediaCenter;
		this.person = person;
		initMediaCenterDIST();
	}
	
	public Press(String mediaName, String contactPersonName, String contactPhoneNumber, String name, int id) throws InputMismatchException, RegistrationException
	{
		initMediaCenterDIST();
		if(mediaCenterDIST.getFlyWeight(mediaName) == null)
		{
			this.mediaCenter = new MediaCenter(mediaName, contactPersonName, contactPhoneNumber);
		}
		else
		{
			this.mediaCenter = mediaCenterDIST.getFlyWeight(mediaName);
		}
		this.person = new Person(name, id);
	}
	
	public FlyWeightMediaCenter getMediaCenterDIST() {
		return mediaCenterDIST;
	}

	public void initMediaCenterDIST() {
		if(this.mediaCenterDIST == null)
			this.mediaCenterDIST = new FlyWeightMediaCenter();
	}

	@Override
	public boolean isAuthorized() {
		//System.out.println(" ...isn't Authorized");
		return false;
	}
	

}
//End.