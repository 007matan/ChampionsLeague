//71070 --- New --- 2021 --- New (FlyWeight)
//Start:
package Model;

import java.util.ArrayList;
import java.util.List;

public class FlyWeightMediaCenter {
	ArrayList <MediaCenter> mediaCenterArr;
	
	public FlyWeightMediaCenter()
	{
		this.mediaCenterArr = new ArrayList<MediaCenter>();
	}
	
	public MediaCenter getFlyWeight(String mediaName)
	{
		int found = 0;
		for(int i = 0; i < mediaCenterArr.size(); i++)
			if(mediaCenterArr.get(i).getMediaName().compareToIgnoreCase(mediaName) == 0)
			{
				found = i;
			}
		if(found == 0)
		{
			this.mediaCenterArr.add(new MediaCenter(mediaName, "", ""));
			return null;
		}
		else
			return this.mediaCenterArr.get(found);
	}
}
//End.