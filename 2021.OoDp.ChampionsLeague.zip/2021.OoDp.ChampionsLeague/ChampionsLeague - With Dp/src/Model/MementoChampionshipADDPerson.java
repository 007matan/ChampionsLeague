	//71070 --- New --- 2021 --- New (Memento)
	//Start:
package Model;

import java.util.ArrayList;

public class MementoChampionshipADDPerson {
	ArrayList <Person> participantsList;
	
	public MementoChampionshipADDPerson(ArrayList <Person> participantsList)
	{
		this.participantsList = participantsList;
	}
	
	public ArrayList <Person> getParticipantsList()
	{
		return participantsList;
	}
}
//End.