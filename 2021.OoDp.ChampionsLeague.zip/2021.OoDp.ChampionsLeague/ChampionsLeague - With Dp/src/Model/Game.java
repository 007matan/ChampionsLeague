package Model;

import java.util.InputMismatchException;
import java.util.Vector;

import Inteface.Decisionalble;
//71070 --- New --- 2021 --- New (Prototype)
//Start:
public abstract class Game implements Decisionalble, Cloneable {
	public final static int TENNIS_NUMBER_OF_SETS = 5;
	public final static int BASKETBALL_NUMBER_OF_SETS = 4;
	public final static int SOCCER_NUMBER_OF_SETS = 2;
	
	private Person stComp;
	private Person ndComp;
	private Vector<Integer> stCompResults;
	private Vector<Integer> ndCompResults;
	
	public Game() {
		setStComp(null);
		setNdComp(null);
		setInitialStCompResults(0);
		setInitialNdCompResults(0);
	}
	
	public Game(Person stComp, Person ndComp, int numOfSets) {
		setStComp(stComp);
		setNdComp(ndComp);
		setInitialStCompResults(numOfSets);
		setInitialNdCompResults(numOfSets);
	}
	//71070 --- New --- 2021 --- New (Builder)
	//Start:
	public Game AddStComp(Person stComp)
	{
		setStComp(stComp);
		return this;
	}
	public Game AddNdComp(Person ndComp)
	{
		setNdComp(ndComp);
		return this;
	}
	public Game AddInitialStCompResults(int numOfSets)
	{
		setInitialStCompResults(numOfSets);
		return this;
	}
	public Game AddInitialNdCompResults(int numOfSets)
	{
		setInitialNdCompResults(numOfSets);
		return this;
	}
	//End.
	public Person getStComp() {
		return stComp;
	}
	public void setStComp(Person stComp) throws InputMismatchException {
		this.stComp = stComp;
	}
	public Person getNdComp() {
		return ndComp;
	}
	public void setNdComp(Person ndComp) throws InputMismatchException {
		this.ndComp = ndComp;
	}
	public void setInitialStCompResults(int size) {
		this.stCompResults = new Vector <Integer>(size);
	}
	public void setStCompResults(Vector <Integer> stCompResults) {
		this.stCompResults = stCompResults;
	}
	public Vector<Integer> getStCompResults() {
		return stCompResults;
	}
	public void setInitialNdCompResults(int size) {
		this.ndCompResults = new Vector <Integer>(size);
	}
	public void setNdCompResults(Vector <Integer> ndCompResults) {
		this.stCompResults = ndCompResults;
	}
	public Vector<Integer> getNdCompResults() {
		return ndCompResults;
	}
	
	
}
