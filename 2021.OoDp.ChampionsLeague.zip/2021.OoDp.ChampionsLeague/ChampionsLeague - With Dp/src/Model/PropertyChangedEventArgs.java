//71070 --- New --- 2021 --- New (Observer)
//Start:
package Model;

public class PropertyChangedEventArgs<T> {
	public T source;
	public String text;
	public Object value;//Game number

	public PropertyChangedEventArgs(T source, String text, Object newValue) {
		this.source = source;
		this.text = text;
		this.value = newValue;
	}
}
//End.