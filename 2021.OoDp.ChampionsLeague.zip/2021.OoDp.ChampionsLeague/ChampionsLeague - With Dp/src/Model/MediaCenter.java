//71070 --- New --- 2021 --- New (FlyWeight)
//Start:
package Model;

public class MediaCenter {
	private String mediaName;
	private String contactPersonName;
	private String contactPhoneNumber;
	
	public MediaCenter(String mediaName, String contactPersonName, String contactPhoneNumber)
	{
		setMediaName(mediaName);
		setContactPersonName(contactPersonName);
		setContactPhoneNumber(contactPhoneNumber);
	}

	public void setMediaName(String mediaName) {
		this.mediaName = mediaName;
	}

	public void setContactPersonName(String contactPersonName) {
		this.contactPersonName = contactPersonName;
	}

	public void setContactPhoneNumber(String contactPhoneNumber) {
		this.contactPhoneNumber = contactPhoneNumber;
	}

	public String getMediaName() {
		return mediaName;
	}
	
	
}
//End.