package Model;

import java.util.Vector;

import Exceptions.RulesException;

public class Soccer extends Game {

	public Soccer(Person stComp, Person ndComp) {
		super(stComp, ndComp, SOCCER_NUMBER_OF_SETS);
	}
	//71070 --- New --- 2021 --- New (Builder)
	//Start:
	public Soccer()
	{
		super();
	}
	
	public Soccer AddStComp(Person stComp)
	{
		setStComp(stComp);
		return this;
	}
	public Soccer AddNdComp(Person ndComp)
	{
		setNdComp(ndComp);
		return this;
	}
	public Soccer AddInitialStCompResults(int numOfSets)
	{
		setInitialStCompResults(numOfSets);
		return this;
	}
	public Soccer AddInitialNdCompResults(int numOfSets)
	{
		setInitialNdCompResults(numOfSets);
		return this;
	}
	//End.
	public boolean equals (Game other) {
		if(!(other instanceof Soccer))
			return false;
		return true;
	}

	@Override
	public Rate isTheFirstCompWins(Vector<Integer> stCompResults, Vector<Integer> ndCompResults) throws RulesException {
		int stCompScore = 0, ndCompScore = 0;
		for(int i = 0; i < stCompResults.size(); i++) {
			stCompScore+=stCompResults.get(i);
			ndCompScore+=ndCompResults.get(i);
		}
		if(stCompScore > ndCompScore)
			return Rate.WINNER;
		else if(stCompScore < ndCompScore)
			return Rate.LOOSER;
		else {
			throw  new RulesException(stCompScore);
		}
	}
	
	//71070 --- New --- 2021 --- New (Prototype)
	//Start:
	@Override
	public Object clone() throws CloneNotSupportedException
	{
		return new Soccer(this.getStComp(), this.getNdComp());
	}
	//End
}
