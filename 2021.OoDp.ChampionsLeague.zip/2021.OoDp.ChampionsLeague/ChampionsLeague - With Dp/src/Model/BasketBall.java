package Model;

import java.util.Vector;

import Exceptions.RulesException;
import Inteface.Decisionalble.Rate;

public class BasketBall extends Game {
	
	public BasketBall(Person stComp, Person ndComp) {
		super(stComp, ndComp, BASKETBALL_NUMBER_OF_SETS);
	}
	//71070 --- New --- 2021 --- New (Builder)
	//Start:
	public BasketBall()
	{
		super();
	}
	
	public BasketBall AddStComp(Person stComp)
	{
		setStComp(stComp);
		return this;
	}
	public BasketBall AddNdComp(Person ndComp)
	{
		setNdComp(ndComp);
		return this;
	}
	public BasketBall AddInitialStCompResults(int numOfSets)
	{
		setInitialStCompResults(numOfSets);
		return this;
	}
	public BasketBall AddInitialNdCompResults(int numOfSets)
	{
		setInitialNdCompResults(numOfSets);
		return this;
	}
	//End.
	public boolean equals (Game other) {
		if(!(other instanceof BasketBall))
			return false;
		return true;
	}

	@Override
	public Rate isTheFirstCompWins(Vector<Integer> stCompResults, Vector<Integer> ndCompResults) throws RulesException {
		int stCompScore = 0, ndCompScore = 0;
		for(int i = 0; i < stCompResults.size(); i++) {
			stCompScore+=stCompResults.get(i);
			ndCompScore+=ndCompResults.get(i);
		}
		if(stCompScore > ndCompScore)
			return Rate.WINNER;
		else if(stCompScore < ndCompScore)
			return Rate.LOOSER;
		else
		{
			throw  new RulesException(stCompScore);
		}
	}
	
	//71070 --- New --- 2021 --- New (Prototype)
	//Start:
	@Override
	public Object clone() throws CloneNotSupportedException
	{
		return new BasketBall(this.getStComp(), this.getNdComp());
	}
	//End
}
