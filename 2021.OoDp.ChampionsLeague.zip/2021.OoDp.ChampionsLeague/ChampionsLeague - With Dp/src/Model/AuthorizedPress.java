//71070 --- New --- 2021 --- New (Proxy, Facade, Observer, Factory)
//Start:
package Model;

import java.util.InputMismatchException;

import Controller.Controller;
import Exceptions.RegistrationException;
import Inteface.Observer;

public class AuthorizedPress extends Press implements Observer<Controller> {
	
	protected FlyWeightMediaCenter mediaCenterDIST;
	
	
	private AuthorizedPress(MediaCenter mediaCenter, Person person) {
		super(mediaCenter, person);
	}
	
	//
		//on the paper what makes it to be the factory 
		//is that i prevent use the first func above
	//

	public AuthorizedPress(String mediaName, String contactPersonName, String contactPhoneNumber, String name, int id) throws InputMismatchException, RegistrationException
	{
		super(mediaName, contactPersonName, contactPhoneNumber, name, id);
	}
	
	@Override
	public boolean isAuthorized() {
		String mediaCenterName = mediaCenter.getMediaName();
		if(mediaCenterName.compareToIgnoreCase("BBC") == 0 || mediaCenterName.compareToIgnoreCase("FLYS") == 0 )
			return true;
		System.out.println(person.getPersonName());
		return super.isAuthorized();
	}
	//Add AuthorizedPress queries of the games they have 
	//Actually in the func handler you need to use it

	@Override
	public void handle(PropertyChangedEventArgs<Controller> args) {
		if(isAuthorized())
			System.out.println("Authorized Press" + this.person.getPersonName() + " says and confirmed: " + args.text + "\n");
	}
	
	public boolean equals(AuthorizedPress aP) {
		if(this.person.getId() == aP.person.getId())
			return true;
		return false;
	}
	
}
//End.