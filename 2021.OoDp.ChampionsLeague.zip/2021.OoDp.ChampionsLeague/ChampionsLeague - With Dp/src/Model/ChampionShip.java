package Model;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Vector;

import Exceptions.RegistrationException;


public final class ChampionShip {

	public final static int NUMBER_OF_PARTICIPENTS = 8;
	public final static int NUMBER_OF_FIRST_ROUND_GAMES = 4;
	public final static int NUMBER_OF_SECOND_ROUND_GAMES = 2;
	public final static int NUMBER_OF_FINAL_ROUND_GAME = 1;

	//71070 --- New --- 2021 --- New (Singelton)
	//Start:
	public static ChampionShip instanse;
	//End

	ArrayList <Game> tournament;

	ArrayList <Person> participantsList;

	ArrayList <Person> semiFinalParticipantsList;

	ArrayList <Person> finalParticipantsList;





	ArrayList <AuthorizedPress> authorizedPressList; 




	//71070 --- New --- 2021 --- New (Singelton)
	//Start:
	static {
		try {
			instanse = new ChampionShip();
		}catch (Exception e) {
			System.out.println("Failed creating " + ChampionShip.class.getSimpleName() + "; " + e);
		}
	}
	//End

	private ChampionShip() {
		this.tournament = null;
		this.participantsList = new ArrayList <Person>(8);
		this.semiFinalParticipantsList = new ArrayList <Person>(4);
		this.finalParticipantsList =  new ArrayList<Person>(2);
		
		
		this.authorizedPressList = new ArrayList<AuthorizedPress>(1);
		
		
	}



	public ArrayList<Person> getParticipantsList() {
		return participantsList;
	}

	public ArrayList<Person> getSemiFinalParticipantsList() {
		return semiFinalParticipantsList;
	}

	public ArrayList<Game> getTournament() {
		return tournament;
	}


	public ArrayList<Person> getFinalParticipantsList() {
		return finalParticipantsList;
	}

	//Add Person - 
	//The function gets: String (name) , int (id).
	//The function will create a new person, if the person does not exist (by id), and if is not 8 participants already. (return before 2021 void) 
	public MementoChampionshipADDPerson addPerson(String name, int id) throws InputMismatchException,RegistrationException, Exception{
		if(participantsList.size() < 8) {
			boolean found = false;
			Person tmpPerson = new Person(name, id);
			for(int i = 0; i < participantsList.size(); i++) {
				if(tmpPerson.equals(participantsList.get(i))) {
					found = true;
					break;
				}
			}
			if(!found) {
				participantsList.add(tmpPerson);
				//71070 --- New --- 2021 --- New (Memento)
				//Start:
				return new MementoChampionshipADDPerson(participantsList);
				//End
			}
			else
				throw new Exception("There are a participent like " + tmpPerson.getId() + " which have same Id number");
		}
		else {
			throw new Exception("There are already 8 participants");
		}

	}

	//71070 --- New --- 2021 --- New (Memento)
	//Start:
	//DeletePerson (Sort of memento just for that part)
	//Like withdraw/Deposit -> AddPerson Delete
	public void UndoAddPerson(MementoChampionshipADDPerson memento)
	{
		participantsList = memento.getParticipantsList();
		participantsList.remove(memento.getParticipantsList().size() - 1);
	}
	//End.

	//71070 --- New --- 2021 --- New 
	//Start:
	public AuthorizedPress addAutorizedPress(String mediaName, String contactPersonName, String contactPhoneNumber, String name, int id) throws InputMismatchException, RegistrationException, Exception {

		boolean found = false;
		AuthorizedPress press = new AuthorizedPress(mediaName, contactPersonName, contactPhoneNumber, name, id);
		for(int i = 0; i < authorizedPressList.size(); i++) {
			if(press.equals(authorizedPressList.get(i))) {
				found = true;
				break;
			}
		}
		if(!found) {
			authorizedPressList.add(press);
		}
		else
			throw new Exception("There are a participent like which have same Id number");
		return press;
	}
//End..

//Start The Tour - 
//The function gets: String (game).
//The function will create the Quarter final. 
public void startTheTour(String game) {
	int participentsIndex;
	ArrayList<Game> firstRound = new ArrayList<Game>(NUMBER_OF_FIRST_ROUND_GAMES);
	if(getParticipantsList().size() == NUMBER_OF_PARTICIPENTS) {
		if(game == "Tennis") {
			participentsIndex = 0;
			for(int i = 0; i < NUMBER_OF_FIRST_ROUND_GAMES; i++, participentsIndex++) {
				firstRound.add(new Tennis() // Before 2021: firstRound.add(new Tennis(participantsList.get(participentsIndex), participantsList.get(++participentsIndex)));
						.AddStComp(participantsList.get(participentsIndex)) 
						.AddNdComp(participantsList.get(++participentsIndex))
						.AddInitialStCompResults(Tennis.TENNIS_NUMBER_OF_SETS)
						.AddInitialNdCompResults(Tennis.TENNIS_NUMBER_OF_SETS));
			}
		}
		else if(game == "Soccer") {
			participentsIndex = 0;
			for(int i = 0; i < NUMBER_OF_FIRST_ROUND_GAMES; i++, participentsIndex++) {
				firstRound.add(new Soccer() // Before 2021: firstRound.add(new Soccer(participantsList.get(participentsIndex), participantsList.get(++participentsIndex)));
						.AddStComp(participantsList.get(participentsIndex)) 
						.AddNdComp(participantsList.get(++participentsIndex))
						.AddInitialStCompResults(Soccer.SOCCER_NUMBER_OF_SETS)
						.AddInitialNdCompResults(Soccer.SOCCER_NUMBER_OF_SETS)); 
			}
		}
		else if(game == "BasketBall") {
			participentsIndex = 0;
			for(int i = 0; i < NUMBER_OF_FIRST_ROUND_GAMES; i++, participentsIndex++) {
				firstRound.add(new BasketBall() //Before 2021: firstRound.add(new BasketBall(participantsList.get(participentsIndex), participantsList.get(++participentsIndex)));
						.AddStComp(participantsList.get(participentsIndex)) 
						.AddNdComp(participantsList.get(++participentsIndex))
						.AddInitialStCompResults(Soccer.BASKETBALL_NUMBER_OF_SETS)
						.AddInitialNdCompResults(Soccer.BASKETBALL_NUMBER_OF_SETS)); 
			}
		}
	}
	tournament = firstRound;
}
//Start The Semi Final Tour - 
//The function gets: String (game).
//The function will create the Semi Final.
public void startSemiFinualTourBuildUp(String name) throws CloneNotSupportedException{
	if(tournament.size() < 6) {
		ArrayList<Game> semiFinal = new ArrayList<Game>(2);
		Game stGame = null, ndGame = null;
		if(name == "Tennis") {
			stGame = new Tennis(semiFinalParticipantsList.get(0), semiFinalParticipantsList.get(1));
			// Before 2021:ndGame = new  Tennis(semiFinalParticipantsList.get(2), semiFinalParticipantsList.get(3)); //you may use clone here
			//71070 --- New --- 2021 --- New (Prototype)
			//Start:
			ndGame = (Game) ((Tennis)stGame).clone();
			//End
			ndGame.AddStComp(semiFinalParticipantsList.get(2))
			.AddNdComp(semiFinalParticipantsList.get(3))
			.AddInitialStCompResults(Tennis.TENNIS_NUMBER_OF_SETS)
			.AddInitialNdCompResults(Tennis.TENNIS_NUMBER_OF_SETS);
		}
		else if(name == "Soccer") {
			stGame = new Soccer(semiFinalParticipantsList.get(0), semiFinalParticipantsList.get(1));
			// Before 2021:	ndGame = new  Soccer(semiFinalParticipantsList.get(2), semiFinalParticipantsList.get(3));//use clone
			//71070 --- New --- 2021 --- New (Prototype)
			//Start:
			ndGame = (Game) ((Soccer)stGame).clone();//End
			ndGame.AddStComp(semiFinalParticipantsList.get(2))
			.AddNdComp(semiFinalParticipantsList.get(3))
			.AddInitialStCompResults(Soccer.SOCCER_NUMBER_OF_SETS)
			.AddInitialNdCompResults(Soccer.SOCCER_NUMBER_OF_SETS);
		}
		else if(name == "BasketBall") {
			stGame = new BasketBall(semiFinalParticipantsList.get(0), semiFinalParticipantsList.get(1));
			// Before 2021:	ndGame = new  BasketBall(semiFinalParticipantsList.get(2), semiFinalParticipantsList.get(3));//use clone
			//71070 --- New --- 2021 --- New (Prototype)
			//Start:
			ndGame = (Game) ((BasketBall)stGame).clone();
			//End
			ndGame.AddStComp(semiFinalParticipantsList.get(2))
			.AddNdComp(semiFinalParticipantsList.get(3))
			.AddInitialStCompResults(BasketBall.BASKETBALL_NUMBER_OF_SETS)
			.AddInitialNdCompResults(BasketBall.BASKETBALL_NUMBER_OF_SETS);
		}
		semiFinal.add(stGame);
		semiFinal.add(ndGame);
		tournament.addAll(semiFinal);
	}
}
//Start The Final Tour - 
//The function gets: String (game).
//The function will create the Final.
public void startFinalTourBuildUp(String name) {
	if(tournament.size() == 6) {
		Game game = null;
		if(name == "Tennis") {
			game = new Tennis(finalParticipantsList.get(0), finalParticipantsList.get(1));
		}
		else if(name == "Soccer") {
			game = new Soccer(finalParticipantsList.get(0), finalParticipantsList.get(1));
		}
		else if(name == "BasketBall") {
			game = new BasketBall(finalParticipantsList.get(0), finalParticipantsList.get(1));
		}
		tournament.add(game);
	}
}	
}
