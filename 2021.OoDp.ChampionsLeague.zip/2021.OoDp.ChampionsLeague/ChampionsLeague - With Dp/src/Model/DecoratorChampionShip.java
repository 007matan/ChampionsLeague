//71070 --- New --- 2021 --- New (Decorator)
		//Start:
package Model;

import java.util.ArrayList;

public class DecoratorChampionShip {
	private ChampionShip championship;
	
	public ArrayList<Person> getParticipantsList() {
		return championship.participantsList;
	}
	
	public ArrayList<Person> getSemiFinalParticipantsList() {
		return championship.semiFinalParticipantsList;
	}

	public ArrayList<Game> getTournament() {
		return championship.tournament;
	}
	

	public ArrayList<Person> getFinalParticipantsList() {
		return championship.finalParticipantsList;
	}
}
//End