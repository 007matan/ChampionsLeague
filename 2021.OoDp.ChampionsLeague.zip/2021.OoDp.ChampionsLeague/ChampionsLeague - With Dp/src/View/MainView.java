package View;


import Model.ChampionsLeagueModel;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.image.*;
import javafx.geometry.*; 
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.*; 
import javafx.scene.layout.*;
import javafx.scene.canvas.*; 
import javafx.scene.web.*;
import java.io.*;
import java.nio.file.attribute.PosixFilePermission;
import java.util.ArrayList;

import javax.naming.NameParser;
import javax.swing.JOptionPane;

import javafx.scene.text.*;
import javafx.scene.paint.*;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;

public class MainView {
	public static int Finals_Text_Fields_Index = 0;
	public static int Clasic_Or_Penaltys = 0; //0 - Classic way  |  1 - penaltys
	private Group root;
	private BorderPane mainBoPane;
	private VBox gameOptionvB;
	private RadioButton soccerRb;
	private RadioButton tennisRb;
	private RadioButton basketBallRb;
	private ToggleGroup gameOptionTg;

	private HBox gamesManRegiHb;

	private VBox personNameVb;
	private Text personNameTxt;
	private TextField personNameTf;

	private VBox personIdVb;
	private Text personIdTxt;
	private TextField personIdTf;

	private Button addParticipantB;
	//71070 --- New --- 2021 --- New (Memento)
	//Start:
	private Button undoAddParticipantB;
	//End.
	
	//71070 --- New --- 2021 --- New 
	//Start:
	private Button addPress;
	//End.
	
	private VBox gamesManRegiVb;

	private VBox participantsVb;

	private TextField participant1Tf;
	private TextField participant2Tf;
	private TextField participant3Tf;
	private TextField participant4Tf;
	private TextField participant5Tf;
	private TextField participant6Tf;
	private TextField participant7Tf;
	private TextField participant8Tf;
	
	private Button playAgame1;
	private Button playAgame2;
	private Button playAgame3;	
	private Button playAgame4;
	private Button playAgame5;	
	private Button playAgame6;
	private Button playAgame7;
	
	private VBox firstRoundVb;
	
	private HBox tournamentHb;

	private Button startTournamentBt;
	private VBox startTournamentVb;
	
	
	private ArrayList <TextField> semiFinalAndFinalParticipantsListTextFieldsToFill;
	
	private TextField semiFinalParticipant1Tf;
	private TextField semiFinalParticipant2Tf;
	private TextField semiFinalParticipant3Tf;
	private TextField semiFinalParticipant4Tf;
	
	private VBox participantsSemiFinalVb;
	private VBox startGameSemiFinalVb;
	
	private TextField finalParticipant1Tf;
	private TextField finalParticipant2Tf;
	
	private VBox participantsFinalVb;
	private VBox startGameFinalVb;
	
	private TextField winnerTf;
	
	private VBox winnerVb;
	
	//71070 --- New --- 2021 --- New 
	//Start:
	
	//******
	private BorderPane PreesRegBp;
	
	private VBox mainPressRegVb;
	private Label pressNameLb;
	private Label pressIdLb;
	private Label pressCompanyLb;
	private Label pressContPerLb;
	private Label pressContPhoneLb;
	
	private TextField pressNameTf;
	private TextField pressIdTf;
	private TextField pressCompanyTf;
	private TextField pressContPerTf;
	private TextField pressContPhoneTf;
	
	private HBox pressNameHb;
	private HBox pressIdHb;
	private HBox pressCompanyHb;
	private HBox pressContPerHb;
	private HBox pressContPhoneHb;
	
	private Button PressRegSubmitButton;
	
	private Label pressRegistrationTitleLb;
	
	private Stage pressStage;
	private Scene pressScene;
	
	
	//**
	//End..
	
	//******
	private BorderPane soccerGameReBp;
	
	private VBox soccerOpOpVb;
	private Label soccerOpStLb;
	private Label soccerOpNdLb;
	private Button soccerSubmitResultsButton;
	private TextField soccerStOpResult1Tf;
	private TextField soccerStOpResult2Tf;
	private HBox soccerStResultsListHb;
	private TextField soccerNdOpResult1Tf;
	private TextField soccerNdOpResult2Tf;
	private HBox soccerNdResultsListHb;
	private HBox soccerSubmitHb;
	
	private VBox soccerOrderResults;
	private Label soccerTitelLb;
	
	//**
	private BorderPane basKetBallGameReBp;
	
	private VBox basKetBallOpOpVb;
	private Label basKetBallOpStLb;
	private Label basKetBallOpNdLb;
	private Button basKetBallSubmitResultsButton;
	private TextField basKetBallStOpResult1Tf;
	private TextField basKetBallStOpResult2Tf;
	private TextField basKetBallStOpResult3Tf;
	private TextField basKetBallStOpResult4Tf;
	private HBox basKetBallStResultsListHb;
	private TextField basKetBallNdOpResult1Tf;
	private TextField basKetBallNdOpResult2Tf;
	private TextField basKetBallNdOpResult3Tf;
	private TextField basKetBallNdOpResult4Tf;
	private HBox basKetBallNdResultsListHb;
	private HBox basKetBallSubmitHb;
	
	private VBox basKetBallOrderResults;
	private Label basKetBallTitelLb;
	
	//**
	private BorderPane tennisGameReBp;
	
	private VBox tennisOpOpVb;
	private Label tennisOpStLb;
	private Label tennisOpNdLb;
	private Button tennisSubmitResultsButton;
	private TextField tennisStOpResult1Tf;
	private TextField tennisStOpResult2Tf;
	private TextField tennisStOpResult3Tf;
	private TextField tennisStOpResult4Tf;
	private TextField tennisStOpResult5Tf;
	private HBox tennisStResultsListHb;
	private TextField tennisNdOpResult1Tf;
	private TextField tennisNdOpResult2Tf;
	private TextField tennisNdOpResult3Tf;
	private TextField tennisNdOpResult4Tf;
	private TextField tennisNdOpResult5Tf;
	private HBox tennisNdResultsListHb;
	private HBox tennisSubmitHb;
	
	private VBox tennisOrderResults;
	private Label tennisTitelLb;
	
	//**
	
	private Stage tennisGameReStage;
	private Scene tennisGameReScene; 
	
	private Stage basKetBallGameReStage;
	private Scene basKetBallGameReScene;
	
	private Stage soccerGameReStage;
	private Scene soccerGameReScene;
	
	
	
	//Penalty
	private Stage penaltyStage;
	private Scene penaltyScene;
	
	private BorderPane penaltyBp;
	private VBox penaltyOpOpVb;
	private Label penaltyOpStLb;
	private Label penaltyOpNdLb;
	private Button penaltySubmitResultsButton;
	private ComboBox penaltyStOpResult1Cb;
	private ComboBox penaltyStOpResult2Cb;
	private ComboBox penaltyStOpResult3Cb;
	private ComboBox penaltyStOpResult4Cb;
	private ComboBox penaltyStOpResult5Cb;
	private HBox penaltyStResultsListHb;
	private ComboBox penaltyNdOpResult1Cb;
	private ComboBox penaltyNdOpResult2Cb;
	private ComboBox penaltyNdOpResult3Cb;
	private ComboBox penaltyNdOpResult4Cb;
	private ComboBox penaltyNdOpResult5Cb;
	private HBox penaltyNdResultsListHb;
	private HBox penaltySubmitHb;
	
	private VBox penaltyOrderResults;
	private Label penaltyTitelLb;


	public MainView(Stage stage) throws FileNotFoundException {
		root = new Group();
		stage.setTitle("Champions League Tournament");
		mainBoPane = new BorderPane(); 
		try {
			FileInputStream input = new FileInputStream("C:\\WorkSpaceLibrary\\ChampionsLeague\\src\\Image\\ChampionsLeague.png"); 
			Image image = new Image(input);
			BackgroundImage backgroundimage = new BackgroundImage(image,  
					BackgroundRepeat.NO_REPEAT,  
					BackgroundRepeat.NO_REPEAT,  
					BackgroundPosition.DEFAULT,  
					new BackgroundSize(1.0, 1.0, true, true, false, false));
			Background background = new Background(backgroundimage); 
			mainBoPane.setBackground(background);

			// RightSide - Main view START
			gameOptionTg = new ToggleGroup();
			

			soccerRb = new RadioButton();
			soccerRb.setText("Soccer");
			soccerRb.setTextFill(Color.WHITE);
			soccerRb.setToggleGroup(gameOptionTg);


			basketBallRb = new RadioButton();
			basketBallRb.setText("Basketball");
			basketBallRb.setTextFill(Color.ORANGERED);
			basketBallRb.setToggleGroup(gameOptionTg);

			tennisRb = new RadioButton();
			tennisRb.setText("Tennis");
			tennisRb.setTextFill(Color.GREENYELLOW);
			tennisRb.setToggleGroup(gameOptionTg);

			gameOptionvB = new VBox(soccerRb, basketBallRb, tennisRb);
			gameOptionvB.setAlignment(Pos.CENTER_LEFT);

			mainBoPane.setRight(gameOptionvB);
			// RightSide - Main view END

			//Center - Main view START
			personNameTxt = new Text("Stage Name: ");
			personNameTxt.setFill(Color.WHITE);
			personNameTf = new TextField();
			personNameVb = new VBox();
			personNameVb.getChildren().addAll(personNameTxt, personNameTf);

			personIdTxt = new Text("ID: ");
			personIdTxt.setFill(Color.WHITE);
			personIdTf = new TextField();
			personIdVb = new VBox();
			personIdVb.getChildren().addAll(personIdTxt, personIdTf);

			addParticipantB = new Button();
			addParticipantB.setText("Add participant");
			
			//71070 --- New --- 2021 --- New (Memento)
			//Start:
			undoAddParticipantB = new Button();
			undoAddParticipantB.setText("Undo participant");
			/////////
			
			//71070 --- New --- 2021 --- New 
			//Start:
			addPress = new Button();
			addPress.setText("New Press ? So press...");
			//End..

			gamesManRegiHb = new HBox(personNameVb, personIdVb);
			gamesManRegiHb.setAlignment(Pos.CENTER_RIGHT);
			gamesManRegiHb.setSpacing(40);

			gamesManRegiVb = new VBox(gamesManRegiHb, addParticipantB, undoAddParticipantB,addPress);//End.
			gamesManRegiVb.setPadding(new Insets(200));
			gamesManRegiVb.setSpacing(50);
			gamesManRegiVb.setAlignment(Pos.CENTER);

			mainBoPane.setCenter(gamesManRegiVb);
			// CENTER - Main view END

			// LeftSide - Main view START
			participant1Tf = new TextField();
			participant2Tf = new TextField();
			participant3Tf = new TextField();
			participant4Tf = new TextField();
			participant5Tf = new TextField();
			participant6Tf = new TextField();
			participant7Tf = new TextField();
			participant8Tf = new TextField();

			participantsVb = new VBox(participant1Tf, participant2Tf, participant3Tf, participant4Tf, participant5Tf, participant6Tf, participant7Tf, participant8Tf);
			participantsVb.setPadding(new Insets(10));
			participantsVb.setSpacing(40);
			participantsVb.setAlignment(Pos.CENTER);
			
			playAgame1 = new Button("Play a Game!");
			playAgame1.setVisible(false);
			
			playAgame2 = new Button("Play a Game!");
			playAgame2.setVisible(false);
			playAgame2.setDisable(true);
			
			playAgame3 = new Button("Play a Game!");
			playAgame3.setVisible(false);
			playAgame3.setDisable(true);
			
			playAgame4 = new Button("Play a Game!");
			playAgame4.setVisible(false);
			playAgame4.setDisable(true);
			
			firstRoundVb = new VBox(playAgame1, playAgame2, playAgame3, playAgame4);
			firstRoundVb.setSpacing(105);
			firstRoundVb.setAlignment(Pos.CENTER);
			
			
			
			
			semiFinalParticipant1Tf = new TextField();
			semiFinalParticipant1Tf.setVisible(false);
			
			semiFinalParticipant2Tf = new TextField();
			semiFinalParticipant2Tf.setVisible(false);
			
			semiFinalParticipant3Tf = new TextField();
			semiFinalParticipant3Tf.setVisible(false);
			
			semiFinalParticipant4Tf = new TextField();
			semiFinalParticipant4Tf.setVisible(false);
			
			participantsSemiFinalVb = new VBox(semiFinalParticipant1Tf, semiFinalParticipant2Tf, semiFinalParticipant3Tf, semiFinalParticipant4Tf);
			participantsSemiFinalVb.setPadding(new Insets(10));
			participantsSemiFinalVb.setSpacing(105);
			participantsSemiFinalVb.setAlignment(Pos.CENTER);
			
			playAgame5 = new Button("Play A Game!");
			playAgame5.setVisible(false);
			playAgame5.setDisable(true);
			
			playAgame6 = new Button("Play A Game");
			playAgame6.setVisible(false);
			playAgame6.setDisable(true);
			
			startGameSemiFinalVb = new VBox(playAgame5, playAgame6);
			startGameSemiFinalVb.setSpacing(230);
			startGameSemiFinalVb.setAlignment(Pos.CENTER);
			
			
			
			finalParticipant1Tf = new TextField();
			finalParticipant1Tf.setVisible(false);
			
			finalParticipant2Tf = new TextField();
			finalParticipant2Tf.setVisible(false);
			
			participantsFinalVb = new VBox(finalParticipant1Tf, finalParticipant2Tf);
			participantsFinalVb.setPadding(new Insets(10));
			participantsFinalVb.setSpacing(105);
			participantsFinalVb.setAlignment(Pos.CENTER);
			
			playAgame7 = new Button("Play A Game");
			playAgame7.setVisible(false);
			playAgame7.setDisable(true);
			
			startGameFinalVb = new VBox(playAgame7);
			startGameFinalVb.setSpacing(500);
			startGameFinalVb.setAlignment(Pos.CENTER);
			
			winnerTf = new TextField();
			winnerTf.setVisible(false);
			winnerTf.setStyle("-fx-text-box-border: green;-fx-background-insets: 0, 2;-fx-background-radius: 0, 0; -fx-focus-color: green;");
			
			winnerVb = new VBox(winnerTf);
			winnerVb.setSpacing(500);
			winnerVb.setPadding(new Insets(10));
			winnerVb.setAlignment(Pos.CENTER);
			
			
			tournamentHb = new HBox(participantsVb);
			mainBoPane.setLeft(tournamentHb);
			// LeftSide - Main view END

			// Top - Main view START

			startTournamentBt = new Button("Start Tournament !");
			startTournamentBt.setVisible(false);
			startTournamentVb = new VBox(startTournamentBt);
			startTournamentVb.setAlignment(Pos.CENTER);
			mainBoPane.setTop(startTournamentVb);
			// Top - Main view END

			Scene scene = new Scene(mainBoPane, 950, 670);
			stage.setScene(scene);
			stage.show();
			
			
			//71070 --- New --- 2021 --- New 
			//Start:
			pressNameLb = new Label("Press name:");
			pressNameTf = new TextField();
			pressNameTf.setPrefWidth(100);
			pressNameHb = new HBox(pressNameLb, pressNameTf);
			pressNameHb.setSpacing(80);
			
			pressIdLb = new Label("Press Id:");
			pressIdTf = new TextField();
			pressIdTf.setPrefWidth(100);
			pressIdHb = new HBox(pressIdLb, pressIdTf);
			pressIdHb.setSpacing(95);
			
			pressCompanyLb = new Label("Company name:");
			pressCompanyTf = new TextField();
			pressCompanyTf.setPrefWidth(100);
			pressCompanyHb = new HBox(pressCompanyLb, pressCompanyTf);
			pressCompanyHb.setSpacing(55);
			
			pressContPerLb = new Label("Conatact Person name:");
			pressContPerTf = new TextField();
			pressContPerTf.setPrefWidth(100);
			pressContPerHb = new HBox(pressContPerLb, pressContPerTf);
			pressContPerHb.setSpacing(22);
			
			pressContPhoneLb = new Label("Contact Person phone:");
			pressContPhoneTf = new TextField();
			pressContPhoneTf.setPrefWidth(100);
			pressContPhoneHb = new HBox(pressContPhoneLb, pressContPhoneTf);
			pressContPhoneHb.setSpacing(15);
			
			pressRegistrationTitleLb = new Label("     Press Registration");
			pressRegistrationTitleLb.setTextFill(Color.BLACK);
			pressRegistrationTitleLb.setAlignment(Pos.TOP_CENTER);
			pressRegistrationTitleLb.setMinWidth(50);
			pressRegistrationTitleLb.setMinHeight(50);
			
			PressRegSubmitButton = new Button("Submit");
			
			mainPressRegVb = new VBox(pressNameHb, pressIdHb, pressCompanyHb, pressContPerHb, pressContPhoneHb, PressRegSubmitButton);
			mainPressRegVb.setAlignment(Pos.BASELINE_LEFT);
			
			PreesRegBp = new BorderPane();
			PreesRegBp.setCenter(mainPressRegVb);
			PreesRegBp.setTop(pressRegistrationTitleLb);
			
			
			FileInputStream inputPress = new FileInputStream("C:\\WorkSpaceLibrary\\ChampionsLeague\\src\\Image\\Press.png"); 
			Image imagePress = new Image(inputPress); 
			BackgroundImage backgroundimagePress = new BackgroundImage(imagePress,  
					BackgroundRepeat.NO_REPEAT,  
					BackgroundRepeat.NO_REPEAT,  
					BackgroundPosition.DEFAULT,  
					new BackgroundSize(1.0, 1.0, true, true, false, false)); 
			Background backgroundBackgroundPress = new Background(backgroundimagePress); 
			PreesRegBp.setBackground(backgroundBackgroundPress);
			
			pressStage = new  Stage();
			pressScene = new Scene(PreesRegBp, 500, 300);
			pressStage.setScene(pressScene);
			
			
			
			//End..
			
			//****************************************
			//****************************************
			//****************************************
			
			soccerOpStLb = new Label("check");
			soccerOpStLb.setTextFill(Color.WHITE);
			soccerOpNdLb = new Label("check");
			soccerOpNdLb.setTextFill(Color.WHITE);
			
			soccerOpOpVb = new VBox(soccerOpStLb, soccerOpNdLb);
			soccerOpOpVb.setSpacing(100);
			soccerOpOpVb.setPadding(new Insets(20));
			soccerOpOpVb.setAlignment(Pos.CENTER);
			
			soccerSubmitResultsButton = new Button("Submit");
			
			soccerStOpResult1Tf = new TextField();
			soccerStOpResult1Tf.setPrefWidth(30);
			soccerStOpResult2Tf = new TextField();
			soccerStOpResult2Tf.setPrefWidth(30);
			
			soccerStResultsListHb = new HBox(soccerStOpResult1Tf, soccerStOpResult2Tf);
			soccerStResultsListHb.setSpacing(20);
			soccerStResultsListHb.setAlignment(Pos.CENTER);
			
			soccerNdOpResult1Tf = new TextField();
			soccerNdOpResult1Tf.setPrefWidth(30);
			soccerNdOpResult2Tf = new TextField();
			soccerNdOpResult2Tf.setPrefWidth(30);
			
			soccerNdResultsListHb = new HBox(soccerNdOpResult1Tf, soccerNdOpResult2Tf);
			soccerNdResultsListHb.setSpacing(20);
			soccerNdResultsListHb.setAlignment(Pos.CENTER);
			
			soccerOrderResults = new VBox(soccerStResultsListHb, soccerNdResultsListHb);
			soccerOrderResults.setSpacing(90);
			soccerOrderResults.setAlignment(Pos.CENTER);
			
			soccerSubmitHb = new HBox(soccerOpOpVb, soccerOrderResults, soccerSubmitResultsButton);
			soccerSubmitHb.setAlignment(Pos.CENTER);
			
			soccerTitelLb = new Label("     Enter the halfs's results of the match - at the HALF'S designated places");
			soccerTitelLb.setTextFill(Color.BLACK);
			soccerTitelLb.setAlignment(Pos.TOP_CENTER);
			
			
			
			soccerGameReBp = new BorderPane();
			soccerGameReBp.setCenter(soccerSubmitHb);
			soccerGameReBp.setTop(soccerTitelLb);
			
			FileInputStream inputSoccer = new FileInputStream("C:\\WorkSpaceLibrary\\ChampionsLeague\\src\\Image\\Soccer.png"); 
			Image imageSoccer = new Image(inputSoccer); 
			BackgroundImage backgroundimageSoccer = new BackgroundImage(imageSoccer,  
					BackgroundRepeat.NO_REPEAT,  
					BackgroundRepeat.NO_REPEAT,  
					BackgroundPosition.DEFAULT,  
					new BackgroundSize(1.0, 1.0, true, true, false, false)); 
			Background backgroundBackgroundSoccer = new Background(backgroundimageSoccer); 
			soccerGameReBp.setBackground(backgroundBackgroundSoccer);
		
			soccerGameReStage = new  Stage();
			soccerGameReScene = new Scene(soccerGameReBp, 400,300);
			soccerGameReStage.setScene(soccerGameReScene);
			
			//****************************************
			//****************************************
			//****************************************
			
			//****************************************
			//****************************************
			//****************************************
			
			basKetBallOpStLb = new Label("check");
			basKetBallOpStLb.setTextFill(Color.WHITE);
			basKetBallOpNdLb = new Label("check");
			basKetBallOpNdLb.setTextFill(Color.WHITE);
			
			basKetBallOpOpVb = new VBox(basKetBallOpStLb, basKetBallOpNdLb);
			basKetBallOpOpVb.setSpacing(100);
			basKetBallOpOpVb.setPadding(new Insets(20));
			basKetBallOpOpVb.setAlignment(Pos.CENTER);
			
			basKetBallSubmitResultsButton = new Button("Submit");
			
			basKetBallStOpResult1Tf = new TextField();
			basKetBallStOpResult1Tf.setPrefWidth(30);
			basKetBallStOpResult2Tf = new TextField();
			basKetBallStOpResult2Tf.setPrefWidth(30);
			basKetBallStOpResult3Tf = new TextField();
			basKetBallStOpResult3Tf.setPrefWidth(30);
			basKetBallStOpResult4Tf = new TextField();
			basKetBallStOpResult4Tf.setPrefWidth(30);
			
			basKetBallStResultsListHb = new HBox(basKetBallStOpResult1Tf, basKetBallStOpResult2Tf, basKetBallStOpResult3Tf, basKetBallStOpResult4Tf);
			basKetBallStResultsListHb.setSpacing(20);
			basKetBallStResultsListHb.setAlignment(Pos.CENTER);
			
			basKetBallNdOpResult1Tf = new TextField();
			basKetBallNdOpResult1Tf.setPrefWidth(30);
			basKetBallNdOpResult2Tf = new TextField();
			basKetBallNdOpResult2Tf.setPrefWidth(30);
			basKetBallNdOpResult3Tf = new TextField();
			basKetBallNdOpResult3Tf.setPrefWidth(30);
			basKetBallNdOpResult4Tf = new TextField();
			basKetBallNdOpResult4Tf.setPrefWidth(30);
			
			basKetBallNdResultsListHb = new HBox(basKetBallNdOpResult1Tf, basKetBallNdOpResult2Tf, basKetBallNdOpResult3Tf, basKetBallNdOpResult4Tf);
			basKetBallNdResultsListHb.setSpacing(20);
			basKetBallNdResultsListHb.setAlignment(Pos.CENTER);
			
			basKetBallOrderResults = new VBox(basKetBallStResultsListHb, basKetBallNdResultsListHb);
			basKetBallOrderResults.setSpacing(90);
			basKetBallOrderResults.setAlignment(Pos.CENTER);
			
			basKetBallSubmitHb = new HBox(basKetBallOpOpVb, basKetBallOrderResults, basKetBallSubmitResultsButton);
			basKetBallSubmitHb.setAlignment(Pos.CENTER);
			
			basKetBallTitelLb = new Label("Enter the quater's results of the match - at the QUATER'S designated places");
			basKetBallTitelLb.setTextFill(Color.WHITE);
			basKetBallTitelLb.setAlignment(Pos.TOP_CENTER);
			
			
			basKetBallGameReBp = new BorderPane();
			basKetBallGameReBp.setCenter(basKetBallSubmitHb);
			basKetBallGameReBp.setTop(basKetBallTitelLb);
			
			FileInputStream inputBasketBall = new FileInputStream("C:\\WorkSpaceLibrary\\ChampionsLeague\\src\\Image\\BasketBall.png"); 
			Image imageBasketBall = new Image(inputBasketBall);
			BackgroundImage backgroundimageBasketBall = new BackgroundImage(imageBasketBall,  
					BackgroundRepeat.NO_REPEAT,  
					BackgroundRepeat.NO_REPEAT,  
					BackgroundPosition.DEFAULT,  
					new BackgroundSize(1.0, 1.0, true, true, false, false));  
			Background backgroundBackgroundBasketBall = new Background(backgroundimageBasketBall); 
			basKetBallGameReBp.setBackground(backgroundBackgroundBasketBall);
		
			basKetBallGameReStage = new  Stage();
			basKetBallGameReScene = new Scene(basKetBallGameReBp, 400,300);
			basKetBallGameReStage.setScene(basKetBallGameReScene);
			
			//****************************************
			//****************************************
			//****************************************
			
			//****************************************
			//****************************************
			//****************************************
			
			tennisOpStLb = new Label("check");
			tennisOpStLb.setTextFill(Color.WHITE);
			tennisOpNdLb = new Label("check");
			tennisOpNdLb.setTextFill(Color.WHITE);
			
			tennisOpOpVb = new VBox(tennisOpStLb, tennisOpNdLb);
			tennisOpOpVb.setSpacing(100);
			tennisOpOpVb.setPadding(new Insets(20));
			tennisOpOpVb.setAlignment(Pos.CENTER);
			
			tennisSubmitResultsButton = new Button("Submit");
			
			tennisStOpResult1Tf = new TextField();
			tennisStOpResult1Tf.setPrefWidth(30);
			tennisStOpResult2Tf = new TextField();
			tennisStOpResult2Tf.setPrefWidth(30);
			tennisStOpResult3Tf = new TextField();
			tennisStOpResult3Tf.setPrefWidth(30);
			tennisStOpResult4Tf = new TextField();
			tennisStOpResult4Tf.setPrefWidth(30);
			tennisStOpResult5Tf = new TextField();
			tennisStOpResult5Tf.setPrefWidth(30);
			
			tennisStResultsListHb = new HBox(tennisStOpResult1Tf, tennisStOpResult2Tf, tennisStOpResult3Tf, tennisStOpResult4Tf, tennisStOpResult5Tf);
			tennisStResultsListHb.setSpacing(20);
			tennisStResultsListHb.setAlignment(Pos.CENTER);
			
			tennisNdOpResult1Tf = new TextField();
			tennisNdOpResult1Tf.setPrefWidth(30);
			tennisNdOpResult2Tf = new TextField();
			tennisNdOpResult2Tf.setPrefWidth(30);
			tennisNdOpResult3Tf = new TextField();
			tennisNdOpResult3Tf.setPrefWidth(30);
			tennisNdOpResult4Tf = new TextField();
			tennisNdOpResult4Tf.setPrefWidth(30);
			tennisNdOpResult5Tf = new TextField();
			tennisNdOpResult5Tf.setPrefWidth(30);
			
			tennisNdResultsListHb = new HBox(tennisNdOpResult1Tf, tennisNdOpResult2Tf, tennisNdOpResult3Tf, tennisNdOpResult4Tf, tennisNdOpResult5Tf);
			tennisNdResultsListHb.setSpacing(20);
			tennisNdResultsListHb.setAlignment(Pos.CENTER);
			
			tennisOrderResults = new VBox(tennisStResultsListHb, tennisNdResultsListHb);
			tennisOrderResults.setSpacing(90);
			tennisOrderResults.setAlignment(Pos.CENTER);
			
			tennisSubmitHb = new HBox(tennisOpOpVb, tennisOrderResults, tennisSubmitResultsButton);
			tennisSubmitHb.setAlignment(Pos.CENTER);
			
			tennisTitelLb = new Label("        Enter the set's results of the match - at the SET'S designated places");
			tennisTitelLb.setTextFill(Color.WHITE);
			tennisTitelLb.setAlignment(Pos.TOP_CENTER);
			
			tennisGameReBp = new BorderPane();
			tennisGameReBp.setCenter(tennisSubmitHb);
			tennisGameReBp.setTop(tennisTitelLb);
		
			
			FileInputStream inputTennis = new FileInputStream("C:\\WorkSpaceLibrary\\ChampionsLeague\\src\\Image\\Tennis.png"); 
			Image imageTennis = new Image(inputTennis);
			BackgroundImage backgroundimageTennis = new BackgroundImage(imageTennis,  
					BackgroundRepeat.NO_REPEAT,  
					BackgroundRepeat.NO_REPEAT,  
					BackgroundPosition.DEFAULT,  
					new BackgroundSize(1.0, 1.0, true, true, false, false)); 
			Background backgroundTennis = new Background(backgroundimageTennis);		tennisGameReBp.setBackground(backgroundTennis);
		
			tennisGameReStage = new  Stage();
			tennisGameReScene = new Scene(tennisGameReBp, 400,300);
			tennisGameReStage.setScene(tennisGameReScene);
			
			//****************************************
			//****************************************
			//****************************************
			//Penalty
			penaltyOpStLb = new Label("check");
			penaltyOpStLb.setTextFill(Color.BLACK);
			penaltyOpNdLb = new Label("check");
			penaltyOpNdLb.setTextFill(Color.BLACK);
			
			penaltyOpOpVb = new VBox(penaltyOpStLb, penaltyOpNdLb);
			penaltyOpOpVb.setSpacing(100);
			penaltyOpOpVb.setPadding(new Insets(20));
			penaltyOpOpVb.setAlignment(Pos.CENTER);
			
			penaltySubmitResultsButton = new Button("Submit");
			
			penaltyStOpResult1Cb = new ComboBox<>();
			penaltyStOpResult1Cb.setPrefWidth(30);
			penaltyStOpResult1Cb.getItems().addAll("0","1");
			penaltyStOpResult2Cb = new ComboBox<>();
			penaltyStOpResult2Cb.setPrefWidth(10);
			penaltyStOpResult2Cb.getItems().addAll("0","1");
			penaltyStOpResult3Cb = new ComboBox<>();
			penaltyStOpResult3Cb.setPrefWidth(30);
			penaltyStOpResult3Cb.getItems().addAll("0","1");
			penaltyStOpResult4Cb = new ComboBox<>();
			penaltyStOpResult4Cb.setPrefWidth(30);
			penaltyStOpResult4Cb.getItems().addAll("0","1");
			penaltyStOpResult5Cb = new ComboBox<>();
			penaltyStOpResult5Cb.setPrefWidth(30);
			penaltyStOpResult5Cb.getItems().addAll("0","1");
			
			penaltyStResultsListHb = new HBox(penaltyStOpResult1Cb, penaltyStOpResult2Cb, penaltyStOpResult3Cb, penaltyStOpResult4Cb, penaltyStOpResult5Cb);
			penaltyStResultsListHb.setSpacing(20);
			penaltyStResultsListHb.setAlignment(Pos.CENTER);
			
			penaltyNdOpResult1Cb = new ComboBox<>();
			penaltyNdOpResult1Cb.setPrefWidth(30);
			penaltyNdOpResult1Cb.getItems().addAll("0","1");
			penaltyNdOpResult2Cb = new ComboBox<>();
			penaltyNdOpResult2Cb.setPrefWidth(30);
			penaltyNdOpResult2Cb.getItems().addAll("0","1");
			penaltyNdOpResult3Cb = new ComboBox<>();
			penaltyNdOpResult3Cb.setPrefWidth(30);
			penaltyNdOpResult3Cb.getItems().addAll("0","1");
			penaltyNdOpResult4Cb = new ComboBox<>();
			penaltyNdOpResult4Cb.setPrefWidth(30);
			penaltyNdOpResult4Cb.getItems().addAll("0","1");
			penaltyNdOpResult5Cb = new ComboBox<>();
			penaltyNdOpResult5Cb.setPrefWidth(30);
			penaltyNdOpResult5Cb.getItems().addAll("0","1");
			
			penaltyNdResultsListHb = new HBox(penaltyNdOpResult1Cb, penaltyNdOpResult2Cb, penaltyNdOpResult3Cb, penaltyNdOpResult4Cb, penaltyNdOpResult5Cb);
			penaltyNdResultsListHb.setSpacing(20);
			penaltyNdResultsListHb.setAlignment(Pos.CENTER);
			
			penaltyOrderResults = new VBox(penaltyStResultsListHb, penaltyNdResultsListHb);
			penaltyOrderResults.setSpacing(90);
			penaltyOrderResults.setAlignment(Pos.CENTER);
			
			penaltySubmitHb = new HBox(penaltyOpOpVb, penaltyOrderResults, penaltySubmitResultsButton);
			penaltySubmitHb.setAlignment(Pos.CENTER);
			
			penaltyTitelLb = new Label("              Enter the penalty's results of the match - at the PENALTY'S designated places");
			penaltyTitelLb.setTextFill(Color.BLACK);
			penaltyTitelLb.setAlignment(Pos.TOP_CENTER);
			
			penaltyBp = new BorderPane();
			penaltyBp.setCenter(penaltySubmitHb);
			penaltyBp.setTop(penaltyTitelLb);
		
			
			FileInputStream inputPenalty = new FileInputStream("C:\\WorkSpaceLibrary\\ChampionsLeague\\src\\Image\\Penalty.png"); 
			Image imagePenalty = new Image(inputPenalty); 
			BackgroundImage backgroundimagePenalty = new BackgroundImage(imagePenalty,  
					BackgroundRepeat.NO_REPEAT,  
					BackgroundRepeat.NO_REPEAT,  
					BackgroundPosition.DEFAULT,  
					new BackgroundSize(1.0, 1.0, true, true, false, false)); 
			Background backgroundPenalty = new Background(backgroundimagePenalty); 
			penaltyBp.setBackground(backgroundPenalty);
		
			penaltyStage = new  Stage();
			penaltyScene = new Scene(penaltyBp, 500,400);
			penaltyStage.setScene(penaltyScene);
		}

		catch (Exception e) { 

			System.out.println(e.getMessage()); 
		}
		semiFinalAndFinalParticipantsListTextFieldsToFill = new ArrayList<TextField>();
		semiFinalAndFinalParticipantsListTextFieldsToFill.add(semiFinalParticipant1Tf);
		semiFinalAndFinalParticipantsListTextFieldsToFill.add(semiFinalParticipant2Tf);
		semiFinalAndFinalParticipantsListTextFieldsToFill.add(semiFinalParticipant3Tf);
		semiFinalAndFinalParticipantsListTextFieldsToFill.add(semiFinalParticipant4Tf);
		semiFinalAndFinalParticipantsListTextFieldsToFill.add(finalParticipant1Tf);
		semiFinalAndFinalParticipantsListTextFieldsToFill.add(finalParticipant2Tf);
		semiFinalAndFinalParticipantsListTextFieldsToFill.add(winnerTf);


	}
	public void setDisablePlayAGame2() {
		playAgame2.setDisable(false);
	}
	public void setDisablePlayAGame3() {
		playAgame3.setDisable(false);
	}
	public void setDisablePlayAGame4() {
		playAgame4.setDisable(false);
	}
	public void setDisablePlayAGame5() {
		playAgame5.setDisable(false);
	}
	public void setDisablePlayAGame6() {
		playAgame6.setDisable(false);
	}
	public void setDisablePlayAGame7() {
		playAgame7.setDisable(false);
	}

	public void showTennisGameReStage() {
		tennisGameReStage.show();
	}
	public void hideTennisGameReStage() {
		tennisGameReStage.close();;
	}
	public void showSoccerGameReStage() {
		soccerGameReStage.show();
	}
	public void hideSoccerGameReStage() {
		soccerGameReStage.close();
	}
	public void showBasKetBallGameReStage() {
		basKetBallGameReStage.show();
	}
	public void hideBasKetBallGameReStage() {
		basKetBallGameReStage.close();
	}
	public void showPenaltyStage() {
		penaltyStage.show();
	}
	public void hidePenaltyStage() {
		penaltyStage.close();
	}
	public void update(ChampionsLeagueModel m) {
		root.getChildren().clear();
	}
	
	public ArrayList<TextField> getSemiFinalAndFinalParticipantsListTextFieldsToFill() {
		return semiFinalAndFinalParticipantsListTextFieldsToFill;
	}
	public Label getSoccerOpStLb() {
		return soccerOpStLb;
	}
	public void setSoccerOpStLb(String soccerOpStLb) {
		this.soccerOpStLb.setText(soccerOpStLb);
	}
	public Label getSoccerOpNdLb() {
		return soccerOpNdLb;
	}
	public void setSoccerOpNdLb(String soccerOpNdLb) {
		this.soccerOpNdLb.setText(soccerOpNdLb);
	}
	public Label getBasKetBallOpStLb() {
		return basKetBallOpStLb;
	}
	public void setBasKetBallOpStLb(String basKetBallOpStLb) {
		this.basKetBallOpStLb.setText(basKetBallOpStLb);
	}
	public Label getBasKetBallOpNdLb() {
		return basKetBallOpNdLb;
	}
	public void setBasKetBallOpNdLb(String basKetBallOpNdLb) {
		this.basKetBallOpNdLb.setText(basKetBallOpNdLb);
	}
	public Label getTennisOpStLb() {
		return tennisOpStLb;
	}
	public void setTennisOpStLb(String tennisOpStLb) {
		this.tennisOpStLb.setText(tennisOpStLb);
	}
	public Label getTennisOpNdLb() {
		return tennisOpNdLb;
	}
	public void setTennisOpNdLb(String tennisOpNdLb) {
		this.tennisOpNdLb.setText(tennisOpNdLb);
	}
	public Stage getTennisGameReStage() {
		return tennisGameReStage;
	}
	public Stage getBasKetBallGameReStage() {
		return basKetBallGameReStage;
	}
	public Stage getSoccerGameReStage() {
		return soccerGameReStage;
	}
	public String getPersonName() {
		return personNameTf.getText();
	}
	public int getPersonId() {
		return Integer.parseInt(personIdTf.getText());
	}
	public String getParticipant1Tf() {
		return participant1Tf.getText();
	}
	public void setParticipant1Tf(String participantName) {
		participant1Tf.setText(participantName);
		participant1Tf.setDisable(true);
		
	}
	public String getParticipant2Tf() {
		return participant2Tf.getText();
	}
	public void setParticipant2Tf(String participantName) {
		participant2Tf.setText(participantName);
		participant2Tf.setDisable(true);
	}
	public String getParticipant3Tf() {
		return participant3Tf.getText();
	}
	public void setParticipant3Tf(String participantName) {
		participant3Tf.setText(participantName);
		participant3Tf.setDisable(true);
	}
	public String getParticipant4Tf() {
		return participant4Tf.getText();
	}
	public void setParticipant4Tf(String participantName) {
		participant4Tf.setText(participantName);
		participant4Tf.setDisable(true);
	}
	public String getParticipant5Tf() {
		return participant5Tf.getText();
	}
	public void setParticipant5Tf(String participantName) {
		participant5Tf.setText(participantName);
		participant5Tf.setDisable(true);
	}
	public String getParticipant6Tf() {
		return participant6Tf.getText();
	}
	public void setParticipant6Tf(String participantName) {
		participant6Tf.setText(participantName);
		participant6Tf.setDisable(true);
	}
	public String getParticipant7Tf() {
		return participant7Tf.getText();
	}
	public void setParticipant7Tf(String participantName) {
		participant7Tf.setText(participantName);
		participant7Tf.setDisable(true);
	}
	public String getParticipant8Tf() {
		return participant8Tf.getText();
	}
	public void setParticipant8Tf(String participantName) {
		participant8Tf.setText(participantName);
		participant8Tf.setDisable(true);
	}
	
	public void setSemiFinalParticipant1Tf(String participantName) {
		semiFinalParticipant1Tf.setText(participantName);
		semiFinalParticipant1Tf.setDisable(true);
	}
	public String getSemiFinalParticipant1Tf() {
		return semiFinalParticipant1Tf.getText();
	}
	public void setSemiFinalParticipant2Tf(String participantName) {
		semiFinalParticipant2Tf.setText(participantName);
		semiFinalParticipant2Tf.setDisable(true);
	}
	public String getSemiFinalParticipant2Tf() {
		return semiFinalParticipant2Tf.getText();
	}
	public void setSemiFinalParticipant3Tf(String participantName) {
		semiFinalParticipant3Tf.setText(participantName);
		semiFinalParticipant3Tf.setDisable(true);
	}
	public String getSemiFinalParticipant3Tf() {
		return semiFinalParticipant3Tf.getText();
	}
	public void setSemiFinalParticipant4Tf(String participantName) {
		semiFinalParticipant4Tf.setText(participantName);
		semiFinalParticipant4Tf.setDisable(true);
	}
	public String getSemiFinalParticipant4Tf() {
		return semiFinalParticipant4Tf.getText();
	}
	
	public void setFinalParticipant1Tf(String participantName) {
		finalParticipant1Tf.setText(participantName);
		finalParticipant1Tf.setDisable(true);
	}
	public String getFinalParticipant1Tf() {
		return finalParticipant1Tf.getText();
	}
	public void setFinalParticipant2Tf(String participantName) {
		finalParticipant2Tf.setText(participantName);
		finalParticipant2Tf.setDisable(true);
	}
	public String getFinalParticipant2Tf() {
		return finalParticipant2Tf.getText();
	}
	//71070 --- New --- 2021 --- New 
	//Start:
	/*
	public Stage getPressStage() {
		return pressStage;
	}
	*/
	public void showPressStage() {
		pressStage.show();
	}
	/*
	public void hidePressStage() {
		pressStage.close();
	}
	*/
	

	public String getPressNameTf() {
		return pressNameTf.getText();
	}
	public int getPressIdTf() {
		return Integer.parseInt(pressIdTf.getText());
	}
	public String getPressCompanyTf() {
		return pressCompanyTf.getText();
	}
	public String getPressContPerTf() {
		return pressContPerTf.getText();
	}
	public String getPressContPhoneTf() {
		return pressContPhoneTf.getText();
	}
	
	public void clearPressNameTf() {
		pressNameTf.clear();
	}
	public void clearPressIdTf() {
		pressIdTf.clear();;
	}
	public void clearPressCompanyTf() {
		pressCompanyTf.clear();
	}
	public void clearPressContPerTf() {
		pressContPerTf.clear();
	}
	public void clearPressContPhoneTf() {
		pressContPhoneTf.clear();
	}
	//End...
	public void addEventHandlerToAddParticipantButton(EventHandler<ActionEvent> eventToAddParticipantButton) {
		addParticipantB.setOnAction(eventToAddParticipantButton);
	}
	
	
	
	//71070 --- New --- 2021 --- New (Memento)
		//Start:
	public void addEventHandlerToUndoAddParticipantButton(EventHandler<ActionEvent> eventToUndoAddParticipantButton) {
		undoAddParticipantB.setOnAction(eventToUndoAddParticipantButton);
	}
	//End
	
	//71070 --- New --- 2021 --- New 
	//Start:
	public void addEventHandlerToAddPressButton(EventHandler<ActionEvent> eventTAddPressButton) {
		addPress.setOnAction(eventTAddPressButton);
	}
	
	public void addEventHandlerToSubmitRegPressButton(EventHandler<ActionEvent> eventSubmitRegPressButton) {
		PressRegSubmitButton.setOnAction(eventSubmitRegPressButton);
	}
	//End..
	
	public void addEventHandlerToStartTournamentButton(EventHandler<ActionEvent> eventToStartTournamentButton) {
		startTournamentBt.setOnAction(eventToStartTournamentButton);
	}
	public void addEventHandlerToPlayGame1Button(EventHandler<ActionEvent> eventToPlayGame1) {
		playAgame1.setOnAction(eventToPlayGame1);
	}
	public void addEventHandlerToPlayGame2Button(EventHandler<ActionEvent> eventToPlayGame2) {
		playAgame2.setOnAction(eventToPlayGame2);
	}
	public void addEventHandlerToPlayGame3Button(EventHandler<ActionEvent> eventToPlayGame3) {
		playAgame3.setOnAction(eventToPlayGame3);
	}
	public void addEventHandlerToPlayGame4Button(EventHandler<ActionEvent> eventToPlayGame4) {
		playAgame4.setOnAction(eventToPlayGame4);
	}
	public void addEventHandlerToPlayGame5Button(EventHandler<ActionEvent> eventToPlayGame5) {
	    playAgame5.setOnAction(eventToPlayGame5);	
	}
	public void addEventHandlerToPlayGame6Button(EventHandler<ActionEvent> eventToPlayGame6) {
		playAgame6.setOnAction(eventToPlayGame6);
	}
	public void addEventHandlerToPlayGame7Button(EventHandler<ActionEvent> eventToPlayGame7) {
		playAgame7.setOnAction(eventToPlayGame7);
	}
	
	public void addEventHandlerToSoccerGameResultsSubmitButton(EventHandler<ActionEvent> eventSoccerGameResultsButton) {
		soccerSubmitResultsButton.setOnAction(eventSoccerGameResultsButton);
	}
	public void addEventHandlerToTennisGameResultsSubmitButton(EventHandler<ActionEvent> eventTennisGameResultsButton) {
		tennisSubmitResultsButton.setOnAction(eventTennisGameResultsButton);
	}
	public void addEventHandlerToBasketBallResultsSubmitButton(EventHandler<ActionEvent> eventBasketBallGameResultsButton) {
		basKetBallSubmitResultsButton.setOnAction(eventBasketBallGameResultsButton);
	}
	public void addEventHandlerToPenaltysResultsSubmitButton(EventHandler<ActionEvent> eventPenaltysResultsButton) {
		penaltySubmitResultsButton.setOnAction(eventPenaltysResultsButton);
	}

	public void displayErrorMassage(String errorMassage) {
		JOptionPane.showMessageDialog(null, errorMassage);
	}
	public void clearPersonNameTf() {
		personNameTf.clear();
	}
	public void clearPersonIdTf() {
		personIdTf.clear();
	}
	public void addStartTournamentButton() {
		startTournamentBt.setVisible(true);
	}
	public boolean getSoccerButtonISelected() {
		return soccerRb.isSelected();
	}

	public boolean getBasketBallButtonISelected() {
		return basketBallRb.isSelected();
	}

	public boolean getTennisButtonISelected() {
		return tennisRb.isSelected();
	}
	
	public String getSoccerStOpResult1Tf() {
		return soccerStOpResult1Tf.getText();
	}

	public void setSoccerStOpResult1Tf(TextField soccerStOpResult1Tf) {
		this.soccerStOpResult1Tf = soccerStOpResult1Tf;
	}
	
	public void clearSoccerStOpResult1Tf() {
		 soccerStOpResult1Tf.clear();
	}

	public String getSoccerStOpResult2Tf() {
		return soccerStOpResult2Tf.getText();
	}

	public void setSoccerStOpResult2Tf(TextField soccerStOpResult2Tf) {
		this.soccerStOpResult2Tf = soccerStOpResult2Tf;
	}
	public void clearSoccerStOpResult2Tf() {
		 soccerStOpResult2Tf.clear();
	}

	public String getSoccerNdOpResult1Tf() {
		return soccerNdOpResult1Tf.getText();
	}

	public void setSoccerNdOpResult1Tf(TextField soccerNdOpResult1Tf) {
		this.soccerNdOpResult1Tf = soccerNdOpResult1Tf;
	}
	
	public void clearSoccerNdOpResult1Tf() {
		 soccerNdOpResult1Tf.clear();
	}

	public String getSoccerNdOpResult2Tf() {
		return soccerNdOpResult2Tf.getText();
	}

	public void setSoccerNdOpResult2Tf(TextField soccerNdOpResult2Tf) {
		this.soccerNdOpResult2Tf = soccerNdOpResult2Tf;
	}
	public void clearSoccerNdOpResult2Tf() {
		 soccerNdOpResult2Tf.clear();
	}

	public String getBasKetBallStOpResult1Tf() {
		return basKetBallStOpResult1Tf.getText();
	}

	public void setBasKetBallStOpResult1Tf(TextField basKetBallStOpResult1Tf) {
		this.basKetBallStOpResult1Tf = basKetBallStOpResult1Tf;
	}
	public void clearBasKetBallStOpResult1Tf() {
		basKetBallStOpResult1Tf.clear();
	}

	public String getBasKetBallStOpResult2Tf() {
		return basKetBallStOpResult2Tf.getText();
	}

	public void setBasKetBallStOpResult2Tf(TextField basKetBallStOpResult2Tf) {
		this.basKetBallStOpResult2Tf = basKetBallStOpResult2Tf;
	}
	public void clearBasKetBallStOpResult2Tf() {
		basKetBallStOpResult2Tf.clear();
	}

	public String getBasKetBallStOpResult3Tf() {
		return basKetBallStOpResult3Tf.getText();
	}

	public void setBasKetBallStOpResult3Tf(TextField basKetBallStOpResult3Tf) {
		this.basKetBallStOpResult3Tf = basKetBallStOpResult3Tf;
	}
	public void clearBasKetBallStOpResult3Tf() {
		basKetBallStOpResult3Tf.clear();
	}

	public String getBasKetBallStOpResult4Tf() {
		return basKetBallStOpResult4Tf.getText();
	}

	public void setBasKetBallStOpResult4Tf(TextField basKetBallStOpResult4Tf) {
		this.basKetBallStOpResult4Tf = basKetBallStOpResult4Tf;
	}
	public void clearBasKetBallStOpResult4Tf() {
		basKetBallStOpResult4Tf.clear();
	}

	public String getBasKetBallNdOpResult1Tf() {
		return basKetBallNdOpResult1Tf.getText();
	}

	public void setBasKetBallNdOpResult1Tf(TextField basKetBallNdOpResult1Tf) {
		this.basKetBallNdOpResult1Tf = basKetBallNdOpResult1Tf;
	}
	public void clearBasKetBallNdOpResult1Tf() {
		basKetBallNdOpResult1Tf.clear();
	}

	public String getBasKetBallNdOpResult2Tf() {
		return basKetBallNdOpResult2Tf.getText();
	}

	public void setBasKetBallNdOpResult2Tf(TextField basKetBallNdOpResult2Tf) {
		this.basKetBallNdOpResult2Tf = basKetBallNdOpResult2Tf;
	}
	public void clearBasKetBallNdOpResult2Tf() {
		basKetBallNdOpResult2Tf.clear();
	}

	public String getBasKetBallNdOpResult3Tf() {
		return basKetBallNdOpResult3Tf.getText();
	}

	public void setBasKetBallNdOpResult3Tf(TextField basKetBallNdOpResult3Tf) {
		this.basKetBallNdOpResult3Tf = basKetBallNdOpResult3Tf;
	}
	public void clearBasKetBallNdOpResult3Tf() {
		basKetBallNdOpResult3Tf.clear();
	}

	public String getBasKetBallNdOpResult4Tf() {
		return basKetBallNdOpResult4Tf.getText();
	}

	public void setBasKetBallNdOpResult4Tf(TextField basKetBallNdOpResult4Tf) {
		this.basKetBallNdOpResult4Tf = basKetBallNdOpResult4Tf;
	}
	public void clearBasKetBallNdOpResult4Tf() {
		basKetBallNdOpResult4Tf.clear();
	}

	public String getTennisStOpResult1Tf() {
		return tennisStOpResult1Tf.getText();
	}

	public void setTennisStOpResult1Tf(TextField tennisStOpResult1Tf) {
		this.tennisStOpResult1Tf = tennisStOpResult1Tf;
	}
	public void clearTennisStOpResult1Tf() {
		tennisStOpResult1Tf.clear();
	}

	public String getTennisStOpResult2Tf() {
		return tennisStOpResult2Tf.getText();
	}

	public void setTennisStOpResult2Tf(TextField tennisStOpResult2Tf) {
		this.tennisStOpResult2Tf = tennisStOpResult2Tf;
	}
	public void clearTennisStOpResult2Tf() {
		tennisStOpResult2Tf.clear();
	}

	public String getTennisStOpResult3Tf() {
		return tennisStOpResult3Tf.getText();
	}

	public void setTennisStOpResult3Tf(TextField tennisStOpResult3Tf) {
		this.tennisStOpResult3Tf = tennisStOpResult3Tf;
	}
	public void clearTennisStOpResult3Tf() {
		tennisStOpResult3Tf.clear();
	}

	public String getTennisStOpResult4Tf() {
		return tennisStOpResult4Tf.getText();
	}

	public void setTennisStOpResult4Tf(TextField tennisStOpResult4Tf) {
		this.tennisStOpResult4Tf = tennisStOpResult4Tf;
	}
	public void clearTennisStOpResult4Tf() {
		tennisStOpResult4Tf.clear();
	}

	public String getTennisStOpResult5Tf() {
		return tennisStOpResult5Tf.getText();
	}

	public void setTennisStOpResult5Tf(TextField tennisStOpResult5Tf) {
		this.tennisStOpResult5Tf = tennisStOpResult5Tf;
	}
	public void clearTennisStOpResult5Tf() {
		tennisStOpResult5Tf.clear();
	}

	public String getTennisNdOpResult1Tf() {
		return tennisNdOpResult1Tf.getText();
	}

	public void setTennisNdOpResult1Tf(TextField tennisNdOpResult1Tf) {
		this.tennisNdOpResult1Tf = tennisNdOpResult1Tf;
	}
	public void clearTennisNdOpResult1Tf() {
		tennisNdOpResult1Tf.clear();
	}
	public String getTennisNdOpResult2Tf() {
		return tennisNdOpResult2Tf.getText();
	}
	public void setTennisNdOpResult2Tf(TextField tennisNdOpResult2Tf) {
		this.tennisNdOpResult2Tf = tennisNdOpResult2Tf;
	}
	public void clearTennisNdOpResult2Tf() {
		tennisNdOpResult2Tf.clear();
	}
	public String getTennisNdOpResult3Tf() {
		return tennisNdOpResult3Tf.getText();
	}
	public void setTennisNdOpResult3Tf(TextField tennisNdOpResult3Tf) {
		this.tennisNdOpResult3Tf = tennisNdOpResult3Tf;
	}
	public void clearTennisNdOpResult3Tf() {
		tennisNdOpResult3Tf.clear();
	}
	public String getTennisNdOpResult4Tf() {
		return tennisNdOpResult4Tf.getText();
	}
	public void setTennisNdOpResult4Tf(TextField tennisNdOpResult4Tf) {
		this.tennisNdOpResult4Tf = tennisNdOpResult4Tf;
	}
	public void clearTennisNdOpResult4Tf() {
		tennisNdOpResult4Tf.clear();
	}
	public String getTennisNdOpResult5Tf() {
		return tennisNdOpResult5Tf.getText();
	}
	public void setTennisNdOpResult5Tf(TextField tennisNdOpResult5Tf) {
		this.tennisNdOpResult5Tf = tennisNdOpResult5Tf;
	}
	public void clearTennisNdOpResult5Tf() {
		tennisNdOpResult5Tf.clear();
	}
	
	public Button getSoccerSubmitResultsButton() {
		return soccerSubmitResultsButton;
	}
	public Button getBasKetBallSubmitResultsButton() {
		return basKetBallSubmitResultsButton;
	}
	public Button getTennisSubmitResultsButton() {
		return tennisSubmitResultsButton;
	}
	public TextField getWinnerTf() {
		return winnerTf;
	}
	public void setWinnerTf(TextField winnerTf) {
		this.winnerTf = winnerTf;
	}
	
	public String getPenaltyStOpResult1Cb() {
		return penaltyStOpResult1Cb.getValue().toString();
	}
	public String getPenaltyStOpResult2Cb() {
		return penaltyStOpResult2Cb.getValue().toString();
	}
	public String getPenaltyStOpResult3Cb() {
		return penaltyStOpResult3Cb.getValue().toString();
	}
	public String getPenaltyStOpResult4Cb() {
		return penaltyStOpResult4Cb.getValue().toString();
	}
	public String getPenaltyStOpResult5Cb() {
		return penaltyStOpResult5Cb.getValue().toString();
	}
	public String getPenaltyNdOpResult1Cb() {
		return penaltyNdOpResult1Cb.getValue().toString();
	}
	public String getPenaltyNdOpResult2Cb() {
		return penaltyNdOpResult2Cb.getValue().toString();
	}
	public String getPenaltyNdOpResult3Cb() {
		return penaltyNdOpResult3Cb.getValue().toString();
	}
	public String getPenaltyNdOpResult4Cb() {
		return penaltyNdOpResult4Cb.getValue().toString();
	}
	public String getPenaltyNdOpResult5Cb() {
		return penaltyNdOpResult5Cb.getValue().toString();
	}
	
	public void clearPenaltyStOpResult1Cb() {
		penaltyStOpResult1Cb.getSelectionModel().clearSelection();
	}
	public void clearPenaltyStOpResult2Cb() {
		penaltyStOpResult2Cb.getSelectionModel().clearSelection();
	}
	public void clearPenaltyStOpResult3Cb() {
		penaltyStOpResult3Cb.getSelectionModel().clearSelection();
	}
	public void clearPenaltyStOpResult4Cb() {
		penaltyStOpResult4Cb.getSelectionModel().clearSelection();
	}
	public void clearPenaltyStOpResult5Cb() {
		penaltyStOpResult5Cb.getSelectionModel().clearSelection();
	}
	public void clearPenaltyNdOpResult1Cb() {
		penaltyNdOpResult1Cb.getSelectionModel().clearSelection();
	}
	public void clearPenaltyNdOpResult2Cb() {
		penaltyNdOpResult2Cb.getSelectionModel().clearSelection();
	}
	public void clearPenaltyNdOpResult3Cb() {
		penaltyNdOpResult3Cb.getSelectionModel().clearSelection();
	}
	public void clearPenaltyNdOpResult4Cb() {
		penaltyNdOpResult4Cb.getSelectionModel().clearSelection();
	}
	public void clearPenaltyNdOpResult5Cb() {
		penaltyNdOpResult5Cb.getSelectionModel().clearSelection();
	}
	
	
	public String getPenaltyOpStLb() {
		return penaltyOpStLb.getText();
	}
	public String getPenaltyOpNdLb() {
		return penaltyOpNdLb.getText();
	}
	
	public void setPenaltyOpStLb(String penaltyOpStLb) {
		this.penaltyOpStLb.setText(penaltyOpStLb);
	}
	public void setPenaltyOpNdLb(String penaltyOpNdLb) {
		this.penaltyOpNdLb.setText(penaltyOpNdLb);
	}
	
	public Stage getPenaltyStage() {
		return penaltyStage;
	}
	public void setParticipant1Tf(TextField participant1Tf) {
		this.participant1Tf = participant1Tf;
	}

	public void setParticipant2Tf(TextField participant2Tf) {
		this.participant2Tf = participant2Tf;
	}

	public void setParticipant3Tf(TextField participant3Tf) {
		this.participant3Tf = participant3Tf;
	}

	public void setParticipant4Tf(TextField participant4Tf) {
		this.participant4Tf = participant4Tf;
	}

	public void setParticipant5Tf(TextField participant5Tf) {
		this.participant5Tf = participant5Tf;
	}

	public void setParticipant6Tf(TextField participant6Tf) {
		this.participant6Tf = participant6Tf;
	}

	public void setParticipant7Tf(TextField participant7Tf) {
		this.participant7Tf = participant7Tf;
	}

	public void setParticipant8Tf(TextField participant8Tf) {
		this.participant8Tf = participant8Tf;
	}
	//71070 --- New --- 2021 --- New (Memento)
	//Start:
	public void clearParticipant1Tf() {
		this.participant1Tf.clear();
		this.participant1Tf.setDisable(false);
	}
	public void clearParticipant2Tf() {
		this.participant2Tf.clear();
		this.participant2Tf.setDisable(false);
	}
	public void clearParticipant3Tf() {
		this.participant3Tf.clear();
		this.participant3Tf.setDisable(false);
	}
	public void clearParticipant4Tf() {
		this.participant4Tf.clear();
		this.participant4Tf.setDisable(false);
	}
	public void clearParticipant5Tf() {
		this.participant5Tf.clear();
		this.participant5Tf.setDisable(false);
	}
	public void clearParticipant6Tf() {
		this.participant6Tf.clear();
		this.participant6Tf.setDisable(false);
	}
	public void clearParticipant7Tf() {
		this.participant7Tf.clear();
		this.participant7Tf.setDisable(false);
	}
	public void clearParticipant8Tf() {
		this.participant8Tf.clear();
		this.participant8Tf.setDisable(false);
	}
	//End
	
	public void setSemiFinalParticipant1Tf(TextField semiFinalParticipant1Tf) {
		this.semiFinalParticipant1Tf = semiFinalParticipant1Tf;
	}

	public void setSemiFinalParticipant2Tf(TextField semiFinalParticipant2Tf) {
		this.semiFinalParticipant2Tf = semiFinalParticipant2Tf;
	}

	public void setSemiFinalParticipant3Tf(TextField semiFinalParticipant3Tf) {
		this.semiFinalParticipant3Tf = semiFinalParticipant3Tf;
	}

	public void setSemiFinalParticipant4Tf(TextField semiFinalParticipant4Tf) {
		this.semiFinalParticipant4Tf = semiFinalParticipant4Tf;
	}

	public void setFinalParticipant1Tf(TextField finalParticipant1Tf) {
		this.finalParticipant1Tf = finalParticipant1Tf;
	}

	public void setFinalParticipant2Tf(TextField finalParticipant2Tf) {
		this.finalParticipant2Tf = finalParticipant2Tf;
	}

	public void clearRightSide() {
		gameOptionvB.getChildren().clear();
	}
	public void clearCenterSide() {
		gamesManRegiVb.getChildren().clear();
	}
	public void clearTopSide() {
		startTournamentVb.getChildren().clear();
	}
	public void addfirstRoundVB() {
		playAgame1.setVisible(true);
		playAgame2.setVisible(true);
		playAgame3.setVisible(true);
		playAgame4.setVisible(true);
		semiFinalParticipant1Tf.setVisible(true);
		semiFinalParticipant2Tf.setVisible(true);
		semiFinalParticipant3Tf.setVisible(true);
		semiFinalParticipant4Tf.setVisible(true);
		playAgame5.setVisible(true);
		playAgame6.setVisible(true);
		finalParticipant1Tf.setVisible(true);
		finalParticipant2Tf.setVisible(true);
		playAgame7.setVisible(true);
		winnerTf.setVisible(true);
		tournamentHb.getChildren().addAll(firstRoundVb, participantsSemiFinalVb, startGameSemiFinalVb, participantsFinalVb, startGameFinalVb, winnerVb);
	}
}
