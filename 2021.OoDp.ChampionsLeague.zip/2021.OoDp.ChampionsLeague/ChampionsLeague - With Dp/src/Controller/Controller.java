package Controller;


import java.util.InputMismatchException;
import java.util.Vector;
import java.util.concurrent.Semaphore;

import Exceptions.RegistrationException;
import Exceptions.RulesException;
import Inteface.Decisionalble.Rate;
import Model.AuthorizedPress;
import Model.ChampionShip;
import Model.ChampionsLeagueModel;
import Model.Observable;
import Model.Soccer;
import View.MainView;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

//71070 --- New --- 2021 --- New (Observer)
//Start:
public class Controller extends Observable<Controller> implements Cloneable {
//End.
	private ChampionsLeagueModel championsLeagueModel;
	private MainView championsLeagueView;
	private int gameNumber;
	
	@Override
	public Object clone() throws CloneNotSupportedException{
		return new Controller(championsLeagueModel, championsLeagueView);
	}

	public Controller(ChampionsLeagueModel m, MainView v) {
		championsLeagueModel = m;
		championsLeagueView = v;
		this.gameNumber = 0;

		EventHandler<ActionEvent> eventToAddParticipantButton = new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				String participantName = "";
				int id = 0;
				int participantsNumber = 0;
				try {
					participantName = championsLeagueView.getPersonName();
					if(participantName.isEmpty()) {
						throw new Exception("Enter Stage Name !");
					}
					id = championsLeagueView.getPersonId();
					participantsNumber = championsLeagueModel.addParticipant(participantName, id);
				}
				catch (Exception e) {
					championsLeagueView.displayErrorMassage(e.getMessage());
				}
				switch(participantsNumber) {
				case 1:
					championsLeagueView.setParticipant1Tf(participantName);
					break;
				case 2:
					championsLeagueView.setParticipant2Tf(participantName);
					break;
				case 3:
					championsLeagueView.setParticipant3Tf(participantName);
					break;
				case 4:
					championsLeagueView.setParticipant4Tf(participantName);
					break;
				case 5:
					championsLeagueView.setParticipant5Tf(participantName);
					break;
				case 6:
					championsLeagueView.setParticipant6Tf(participantName);
					break;
				case 7:
					championsLeagueView.setParticipant7Tf(participantName);
					break;
				case 8:
					championsLeagueView.setParticipant8Tf(participantName);
					championsLeagueView.addStartTournamentButton();
					break;
				}

				championsLeagueView.clearPersonNameTf();
				championsLeagueView.clearPersonIdTf();

			}
		};
		championsLeagueView.addEventHandlerToAddParticipantButton(eventToAddParticipantButton);
		
		//71070 --- New --- 2021 --- New
		//Start:
		EventHandler<ActionEvent> eventSubmitRegPressButton = new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				String mediaName;
				String contactPersonName;
				String contactPhoneNumber;
				String name;
				int id;
				try {
					
				mediaName = championsLeagueView.getPressCompanyTf();
				if(mediaName.isEmpty()) {
					throw new Exception("Please enter a mediaName");
				}
				contactPersonName = championsLeagueView.getPressContPerTf();
				if(contactPersonName.isEmpty()) {
					throw new Exception("Please enter a contactPersonName");
				}
				contactPhoneNumber = championsLeagueView.getPressContPhoneTf();
				if(contactPhoneNumber.isEmpty()) {
					throw new Exception("Please enter a contactPhoneNumber");
				}
				name = championsLeagueView.getPressNameTf();
				if(name.isEmpty()) {
					throw new Exception("Please enter a name");
				}
				id = championsLeagueView.getPressIdTf();
				AuthorizedPress aP = championsLeagueModel.addAutorizedPress(mediaName, contactPersonName, contactPhoneNumber, name, id);
				subscribeToController(aP);
				} catch (InputMismatchException e) {
					championsLeagueView.displayErrorMassage(e.getMessage());
				} catch (RegistrationException e) {
					championsLeagueView.displayErrorMassage(e.getMessage());
				} catch (Exception e) {
					championsLeagueView.displayErrorMassage(e.getMessage());
				}
				
				championsLeagueView.clearPressNameTf();
				championsLeagueView.clearPressIdTf();
				championsLeagueView.clearPressCompanyTf();
				championsLeagueView.clearPressContPerTf();
				championsLeagueView.clearPressContPhoneTf();
				
	
				
				
			}
			
		};
		championsLeagueView.addEventHandlerToSubmitRegPressButton(eventSubmitRegPressButton);
		//End...
		
		//71070 --- New --- 2021 --- New (Memento)
		//Start:
		EventHandler<ActionEvent> eventToUndoAddParticipantButton = new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				int lastParticipantNumber =  championsLeagueModel.getTheChampionship().getParticipantsList().size();
				championsLeagueModel.undoParticipant();
				switch(lastParticipantNumber) {
				case 1:
					championsLeagueView.clearParticipant1Tf();
					break;
				case 2:
					championsLeagueView.clearParticipant2Tf();
					break;
				case 3:
					championsLeagueView.clearParticipant3Tf();
					break;
				case 4:
					championsLeagueView.clearParticipant4Tf();
					break;
				case 5:
					championsLeagueView.clearParticipant5Tf();
					break;
				case 6:
					championsLeagueView.clearParticipant6Tf();
					break;
				case 7:
					championsLeagueView.clearParticipant7Tf();
					break;
				case 8:
					championsLeagueView.clearParticipant8Tf();
					break;
				}
			}
		};
		championsLeagueView.addEventHandlerToUndoAddParticipantButton(eventToUndoAddParticipantButton);
		//End

		EventHandler<ActionEvent> eventToStartTournamentButton = new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				if(!championsLeagueView.getBasketBallButtonISelected() && !championsLeagueView.getTennisButtonISelected()
						&&!championsLeagueView.getSoccerButtonISelected())
					championsLeagueView.displayErrorMassage("Please choose the Tournament sport type !  --->");
				else {
					if(championsLeagueView.getBasketBallButtonISelected()) {
						championsLeagueModel.startTheTour("BasketBall");
					}
					if(championsLeagueView.getTennisButtonISelected()) {
						championsLeagueModel.startTheTour("Tennis");
					}
					if(championsLeagueView.getSoccerButtonISelected()){
						championsLeagueModel.startTheTour("Soccer");
					}
					championsLeagueView.clearCenterSide();
					championsLeagueView.clearRightSide();
					championsLeagueView.clearTopSide();
					championsLeagueView.addfirstRoundVB();
				}

			}
		};
		championsLeagueView.addEventHandlerToStartTournamentButton(eventToStartTournamentButton);

		EventHandler<ActionEvent> eventToPlayGame1 = new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				championsLeagueView.Clasic_Or_Penaltys = 0;
				if(championsLeagueModel.getTheChampionship().getTournament().get(1).getClass().getTypeName().toString() == "Model.Soccer") {
					championsLeagueView.showSoccerGameReStage();
				}
				if(championsLeagueModel.getTheChampionship().getTournament().get(1).getClass().getTypeName().toString() == "Model.Tennis") {
					championsLeagueView.showTennisGameReStage();
				}
				if(championsLeagueModel.getTheChampionship().getTournament().get(1).getClass().getTypeName().toString() == "Model.BasketBall") {
					championsLeagueView.showBasKetBallGameReStage();
				}
				gameNumber = 0;
				championsLeagueView.setDisablePlayAGame2();
				String st = championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getStComp().getPersonName(); // same same game number  == "0"
				String nd = championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getNdComp().getPersonName(); // same same just ndop
				championsLeagueView.setSoccerOpStLb(st);
				championsLeagueView.setSoccerOpNdLb(nd);
				championsLeagueView.setTennisOpStLb(st);
				championsLeagueView.setTennisOpNdLb(nd);
				championsLeagueView.setBasKetBallOpStLb(st);
				championsLeagueView.setBasKetBallOpNdLb(nd);
				championsLeagueView.setBasKetBallOpStLb(st);
				championsLeagueView.setBasKetBallOpNdLb(nd);
				championsLeagueView.setPenaltyOpStLb(st);
				championsLeagueView.setPenaltyOpNdLb(nd);
			}

		};
		championsLeagueView.addEventHandlerToPlayGame1Button(eventToPlayGame1);

		EventHandler<ActionEvent> eventToPlayGame2 = new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				championsLeagueView.Clasic_Or_Penaltys = 0;
				if(championsLeagueModel.getTheChampionship().getTournament().get(1).getClass().getTypeName().toString() == "Model.Soccer") {
					championsLeagueView.showSoccerGameReStage();
				}
				if(championsLeagueModel.getTheChampionship().getTournament().get(1).getClass().getTypeName().toString() == "Model.Tennis") {
					championsLeagueView.showTennisGameReStage();
				}
				if(championsLeagueModel.getTheChampionship().getTournament().get(1).getClass().getTypeName().toString() == "Model.BasketBall") {
					championsLeagueView.showBasKetBallGameReStage();
				}
				gameNumber = 1;
				championsLeagueView.setDisablePlayAGame3();
				String st = championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getStComp().getPersonName(); // same same game number  == "1"
				String nd = championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getNdComp().getPersonName(); // same same just ndop
				championsLeagueView.setSoccerOpStLb(st);
				championsLeagueView.setSoccerOpNdLb(nd);
				championsLeagueView.setTennisOpStLb(st);
				championsLeagueView.setTennisOpNdLb(nd);
				championsLeagueView.setBasKetBallOpStLb(st);
				championsLeagueView.setBasKetBallOpNdLb(nd);
				championsLeagueView.setPenaltyOpStLb(st);
				championsLeagueView.setPenaltyOpNdLb(nd);
			}

		};
		championsLeagueView.addEventHandlerToPlayGame2Button(eventToPlayGame2);

		EventHandler<ActionEvent> eventToPlayGame3 = new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				championsLeagueView.Clasic_Or_Penaltys = 0;
				if(championsLeagueModel.getTheChampionship().getTournament().get(1).getClass().getTypeName().toString() == "Model.Soccer") {
					championsLeagueView.showSoccerGameReStage();
				}
				if(championsLeagueModel.getTheChampionship().getTournament().get(1).getClass().getTypeName().toString() == "Model.Tennis") {
					championsLeagueView.showTennisGameReStage();
				}
				if(championsLeagueModel.getTheChampionship().getTournament().get(1).getClass().getTypeName().toString() == "Model.BasketBall") {
					championsLeagueView.showBasKetBallGameReStage();
				}
				gameNumber = 2;
				championsLeagueView.setDisablePlayAGame4();
				String st = championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getStComp().getPersonName(); // same same game number  == "2"
				String nd = championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getNdComp().getPersonName(); // same same just ndop
				championsLeagueView.setSoccerOpStLb(st);
				championsLeagueView.setSoccerOpNdLb(nd);
				championsLeagueView.setTennisOpStLb(st);
				championsLeagueView.setTennisOpNdLb(nd);
				championsLeagueView.setBasKetBallOpStLb(st);
				championsLeagueView.setBasKetBallOpNdLb(nd);
				championsLeagueView.setPenaltyOpStLb(st);
				championsLeagueView.setPenaltyOpNdLb(nd);
			}

		};
		championsLeagueView.addEventHandlerToPlayGame3Button(eventToPlayGame3);

		EventHandler<ActionEvent> eventToPlayGame4 = new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				championsLeagueView.Clasic_Or_Penaltys = 0;
				if(championsLeagueModel.getTheChampionship().getTournament().get(1).getClass().getTypeName().toString() == "Model.Soccer") {
					championsLeagueView.showSoccerGameReStage();
				}
				if(championsLeagueModel.getTheChampionship().getTournament().get(1).getClass().getTypeName().toString() == "Model.Tennis") {
					championsLeagueView.showTennisGameReStage();
				}
				if(championsLeagueModel.getTheChampionship().getTournament().get(1).getClass().getTypeName().toString() == "Model.BasketBall") {
					championsLeagueView.showBasKetBallGameReStage();
				}
				gameNumber = 3;
				championsLeagueView.setDisablePlayAGame5();
				String st = championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getStComp().getPersonName(); // same same game number  == "3"
				String nd = championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getNdComp().getPersonName(); // same same just ndop
				championsLeagueView.setSoccerOpStLb(st);
				championsLeagueView.setSoccerOpNdLb(nd);
				championsLeagueView.setTennisOpStLb(st);
				championsLeagueView.setTennisOpNdLb(nd);
				championsLeagueView.setBasKetBallOpStLb(st);
				championsLeagueView.setBasKetBallOpNdLb(nd);
				championsLeagueView.setPenaltyOpStLb(st);
				championsLeagueView.setPenaltyOpNdLb(nd);
			}

		};
		championsLeagueView.addEventHandlerToPlayGame4Button(eventToPlayGame4);

		EventHandler<ActionEvent> eventToPlayGame5 = new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				championsLeagueView.Clasic_Or_Penaltys = 0;
				if(championsLeagueModel.getTheChampionship().getTournament().get(1).getClass().getTypeName().toString() == "Model.Soccer") {
					championsLeagueView.showSoccerGameReStage();
				}
				if(championsLeagueModel.getTheChampionship().getTournament().get(1).getClass().getTypeName().toString() == "Model.Tennis") {
					championsLeagueView.showTennisGameReStage();
				}
				if(championsLeagueModel.getTheChampionship().getTournament().get(1).getClass().getTypeName().toString() == "Model.BasketBall") {
					championsLeagueView.showBasKetBallGameReStage();
				}
				gameNumber = 4;
				championsLeagueView.setDisablePlayAGame6();
				String st = championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getStComp().getPersonName(); // same same game number  == "4"
				String nd = championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getNdComp().getPersonName(); // same same just ndop
				championsLeagueView.setSoccerOpStLb(st);
				championsLeagueView.setSoccerOpNdLb(nd);
				championsLeagueView.setTennisOpStLb(st);
				championsLeagueView.setTennisOpNdLb(nd);
				championsLeagueView.setBasKetBallOpStLb(st);
				championsLeagueView.setBasKetBallOpNdLb(nd);
				championsLeagueView.setPenaltyOpStLb(st);
				championsLeagueView.setPenaltyOpNdLb(nd);
			}

		};
		championsLeagueView.addEventHandlerToPlayGame5Button(eventToPlayGame5);

		EventHandler<ActionEvent> eventToPlayGame6 = new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				championsLeagueView.Clasic_Or_Penaltys = 0;
				if(championsLeagueModel.getTheChampionship().getTournament().get(1).getClass().getTypeName().toString() == "Model.Soccer") {
					championsLeagueView.showSoccerGameReStage();
				}
				if(championsLeagueModel.getTheChampionship().getTournament().get(1).getClass().getTypeName().toString() == "Model.Tennis") {
					championsLeagueView.showTennisGameReStage();
				}
				if(championsLeagueModel.getTheChampionship().getTournament().get(1).getClass().getTypeName().toString() == "Model.BasketBall") {
					championsLeagueView.showBasKetBallGameReStage();
				}
				gameNumber = 5;
				championsLeagueView.setDisablePlayAGame7();
				String st = championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getStComp().getPersonName(); // same same game number  == "4"
				String nd = championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getNdComp().getPersonName(); // same same just ndop
				championsLeagueView.setSoccerOpStLb(st);
				championsLeagueView.setSoccerOpNdLb(nd);
				championsLeagueView.setTennisOpStLb(st);
				championsLeagueView.setTennisOpNdLb(nd);
				championsLeagueView.setBasKetBallOpStLb(st);
				championsLeagueView.setBasKetBallOpNdLb(nd);
				championsLeagueView.setPenaltyOpStLb(st);
				championsLeagueView.setPenaltyOpNdLb(nd);
			}

		};
		championsLeagueView.addEventHandlerToPlayGame6Button(eventToPlayGame6);

		EventHandler<ActionEvent> eventToPlayGame7 = new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				championsLeagueView.Clasic_Or_Penaltys = 0;
				if(championsLeagueModel.getTheChampionship().getTournament().get(1).getClass().getTypeName().toString() == "Model.Soccer") {
					championsLeagueView.showSoccerGameReStage();
				}
				if(championsLeagueModel.getTheChampionship().getTournament().get(1).getClass().getTypeName().toString() == "Model.Tennis") {
					championsLeagueView.showTennisGameReStage();
				}
				if(championsLeagueModel.getTheChampionship().getTournament().get(1).getClass().getTypeName().toString() == "Model.BasketBall") {
					championsLeagueView.showBasKetBallGameReStage();
				}
				gameNumber = 6;
				String st = championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getStComp().getPersonName(); // same same game number  == "4"
				String nd = championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getNdComp().getPersonName(); // same same just ndop
				championsLeagueView.setSoccerOpStLb(st);
				championsLeagueView.setSoccerOpNdLb(nd);
				championsLeagueView.setTennisOpStLb(st);
				championsLeagueView.setTennisOpNdLb(nd);
				championsLeagueView.setBasKetBallOpStLb(st);
				championsLeagueView.setBasKetBallOpNdLb(nd);
				championsLeagueView.setPenaltyOpStLb(st);
				championsLeagueView.setPenaltyOpNdLb(nd);
			}

		};
		championsLeagueView.addEventHandlerToPlayGame7Button(eventToPlayGame7);

		//71070 --- New --- 2021 --- New 
		//Start:
		
		
		EventHandler<ActionEvent> addEventHandlerToAddPressButton = new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				championsLeagueView.showPressStage();
			}
			
		};
		championsLeagueView.addEventHandlerToAddPressButton(addEventHandlerToAddPressButton);
		//End...

		EventHandler<ActionEvent> addEventHandlerToSoccerGameResultsSubmitButton = new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				Controller  c = new Controller(championsLeagueModel, championsLeagueView);
				StringBuffer strtmp = new StringBuffer();
				boolean tmp = false;
				Vector<Integer> stCompResults = new Vector<Integer>(2);
				Vector<Integer> ndCompResults = new Vector<Integer>(2);
				do {
					tmp = false;
					if(championsLeagueView.Clasic_Or_Penaltys == 2 ) { 
						championsLeagueView.hideSoccerGameReStage();
						championsLeagueView.showPenaltyStage();
					}
					else {
						if(!championsLeagueView.getSoccerGameReStage().isShowing())
						{
							championsLeagueView.clearSoccerStOpResult1Tf();
							championsLeagueView.clearSoccerStOpResult2Tf();
							championsLeagueView.clearSoccerNdOpResult1Tf();
							championsLeagueView.clearSoccerNdOpResult2Tf();
							championsLeagueView.showSoccerGameReStage();

						}
						stCompResults.add(0, Integer.parseInt(championsLeagueView.getSoccerStOpResult1Tf()));
						ndCompResults.add(0, Integer.parseInt(championsLeagueView.getSoccerNdOpResult1Tf()));
						stCompResults.add(1, Integer.parseInt(championsLeagueView.getSoccerStOpResult2Tf()));
						ndCompResults.add(1, Integer.parseInt(championsLeagueView.getSoccerNdOpResult2Tf()));
						try {
							if(championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).isTheFirstCompWins(stCompResults, ndCompResults) == Rate.WINNER) {
								if(gameNumber > -1 && gameNumber < 4) {
									championsLeagueModel.getTheChampionship().getSemiFinalParticipantsList().add(championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getStComp());
									championsLeagueView.getSemiFinalAndFinalParticipantsListTextFieldsToFill().get(View.MainView.Finals_Text_Fields_Index).setText(championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getStComp().getPersonName());
									championsLeagueView.getSemiFinalAndFinalParticipantsListTextFieldsToFill().get(View.MainView.Finals_Text_Fields_Index).setDisable(true);
								}
								else if(gameNumber > 3 && gameNumber < 6) {
									championsLeagueModel.getTheChampionship().getFinalParticipantsList().add(championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getStComp());
									championsLeagueView.getSemiFinalAndFinalParticipantsListTextFieldsToFill().get(View.MainView.Finals_Text_Fields_Index).setText(championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getStComp().getPersonName());
									championsLeagueView.getSemiFinalAndFinalParticipantsListTextFieldsToFill().get(View.MainView.Finals_Text_Fields_Index).setDisable(true);
								}
								else if(gameNumber == 6){
									championsLeagueView.getSemiFinalAndFinalParticipantsListTextFieldsToFill().get(View.MainView.Finals_Text_Fields_Index).setText(championsLeagueModel.getTheChampionship().getFinalParticipantsList().get(0).getPersonName());
								}
								View.MainView.Finals_Text_Fields_Index++;
								
								//71070 --- New --- 2021 --- New (Observer)
								//Start:
								strtmp.append("Game number: ");
								strtmp.append(gameNumber);
								strtmp.append("The Winner is: ");
								strtmp.append(championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getStComp().getPersonName());
								propertyChanged(Controller.this,strtmp.toString(), gameNumber);
								
								//End.....
							}
							else {
								if(gameNumber > -1 && gameNumber < 4) {
									championsLeagueModel.getTheChampionship().getSemiFinalParticipantsList().add(championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getNdComp());
									championsLeagueView.getSemiFinalAndFinalParticipantsListTextFieldsToFill().get(View.MainView.Finals_Text_Fields_Index).setText(championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getNdComp().getPersonName());
									championsLeagueView.getSemiFinalAndFinalParticipantsListTextFieldsToFill().get(View.MainView.Finals_Text_Fields_Index).setDisable(true);
								}
								else if(gameNumber > 3 && gameNumber < 6) {
									championsLeagueModel.getTheChampionship().getFinalParticipantsList().add(championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getNdComp());
									championsLeagueView.getSemiFinalAndFinalParticipantsListTextFieldsToFill().get(View.MainView.Finals_Text_Fields_Index).setDisable(true);
									championsLeagueView.getSemiFinalAndFinalParticipantsListTextFieldsToFill().get(View.MainView.Finals_Text_Fields_Index).setText(championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getNdComp().getPersonName());
								}
								else if(gameNumber == 6){
									championsLeagueView.getSemiFinalAndFinalParticipantsListTextFieldsToFill().get(View.MainView.Finals_Text_Fields_Index).setText(championsLeagueModel.getTheChampionship().getFinalParticipantsList().get(1).getPersonName());
								}
								View.MainView.Finals_Text_Fields_Index++;
								
								//71070 --- New --- 2021 --- New (Observer)
								//Start:
								strtmp.append("Game number: ");
								strtmp.append(gameNumber);
								strtmp.append("The Winner is: ");
								strtmp.append(championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getNdComp().getPersonName());
								propertyChanged(Controller.this,strtmp.toString(), gameNumber);
								//End......
							}
						} catch (RulesException e) {
							championsLeagueView.Clasic_Or_Penaltys++;
							if(championsLeagueView.Clasic_Or_Penaltys == 1)
								championsLeagueView.displayErrorMassage(e.getMessage()+ " You moved to Classic Extention");
							if(championsLeagueView.Clasic_Or_Penaltys == 2)
								championsLeagueView.displayErrorMassage(e.getMessage()+ " You moved to Penalty");
							tmp = true;
						}
						
						championsLeagueView.clearSoccerStOpResult1Tf();
						championsLeagueView.clearSoccerStOpResult2Tf();
						championsLeagueView.clearSoccerNdOpResult1Tf();
						championsLeagueView.clearSoccerNdOpResult2Tf();
						championsLeagueView.hideSoccerGameReStage();
					}
				}
				while(tmp);
				if(gameNumber == 3)
					try {
						championsLeagueModel.getTheChampionship().startSemiFinualTourBuildUp("Soccer");
					} catch (CloneNotSupportedException e) {
						System.out.println(e.getMessage());
					}
				if(gameNumber == 5)
					championsLeagueModel.getTheChampionship().startFinalTourBuildUp("Soccer");
			}
		};
		championsLeagueView.addEventHandlerToSoccerGameResultsSubmitButton(addEventHandlerToSoccerGameResultsSubmitButton);

		EventHandler<ActionEvent> addEventHandlerToTennisGameResultsSubmitButton = new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				StringBuffer strtmp = new StringBuffer();
				boolean tmp;
				Vector<Integer> stCompResults = new Vector<Integer>(5);
				Vector<Integer> ndCompResults = new Vector<Integer>(5);
				do {
					if(!championsLeagueView.getTennisGameReStage().isShowing())
					{
						championsLeagueView.clearTennisStOpResult1Tf();
						championsLeagueView.clearTennisStOpResult2Tf();
						championsLeagueView.clearTennisStOpResult3Tf();
						championsLeagueView.clearTennisStOpResult4Tf();
						championsLeagueView.clearTennisStOpResult5Tf();

						championsLeagueView.clearTennisNdOpResult1Tf();
						championsLeagueView.clearTennisNdOpResult2Tf();
						championsLeagueView.clearTennisNdOpResult3Tf();
						championsLeagueView.clearTennisNdOpResult4Tf();
						championsLeagueView.clearTennisNdOpResult5Tf();

						championsLeagueView.showTennisGameReStage();
					}
					tmp = false;
					stCompResults.add(0, Integer.parseInt(championsLeagueView.getTennisStOpResult1Tf()));
					ndCompResults.add(0, Integer.parseInt(championsLeagueView.getTennisNdOpResult1Tf()));
					stCompResults.add(1, Integer.parseInt(championsLeagueView.getTennisStOpResult2Tf()));
					ndCompResults.add(1, Integer.parseInt(championsLeagueView.getTennisNdOpResult2Tf()));
					stCompResults.add(2, Integer.parseInt(championsLeagueView.getTennisStOpResult3Tf()));
					ndCompResults.add(2, Integer.parseInt(championsLeagueView.getTennisNdOpResult3Tf()));
					stCompResults.add(3, Integer.parseInt(championsLeagueView.getTennisStOpResult4Tf()));
					ndCompResults.add(3, Integer.parseInt(championsLeagueView.getTennisNdOpResult4Tf()));
					stCompResults.add(4, Integer.parseInt(championsLeagueView.getTennisStOpResult5Tf()));
					ndCompResults.add(4, Integer.parseInt(championsLeagueView.getTennisNdOpResult5Tf()));

					try {
						if(championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).isTheFirstCompWins(stCompResults, ndCompResults) == Rate.WINNER) {
							if(gameNumber > -1 && gameNumber < 4) {
								championsLeagueModel.getTheChampionship().getSemiFinalParticipantsList().add(championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getStComp());
								championsLeagueView.getSemiFinalAndFinalParticipantsListTextFieldsToFill().get(View.MainView.Finals_Text_Fields_Index).setDisable(true);								championsLeagueView.getSemiFinalAndFinalParticipantsListTextFieldsToFill().get(View.MainView.Finals_Text_Fields_Index).setText(championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getStComp().getPersonName());
							}
							else if(gameNumber > 3 && gameNumber < 6) {
								championsLeagueModel.getTheChampionship().getFinalParticipantsList().add(championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getStComp());
								championsLeagueView.getSemiFinalAndFinalParticipantsListTextFieldsToFill().get(View.MainView.Finals_Text_Fields_Index).setText(championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getStComp().getPersonName());
								championsLeagueView.getSemiFinalAndFinalParticipantsListTextFieldsToFill().get(View.MainView.Finals_Text_Fields_Index).setDisable(true);							}
							else if(gameNumber == 6){
								championsLeagueView.getSemiFinalAndFinalParticipantsListTextFieldsToFill().get(View.MainView.Finals_Text_Fields_Index).setText(championsLeagueModel.getTheChampionship().getFinalParticipantsList().get(0).getPersonName());
							}

							View.MainView.Finals_Text_Fields_Index++;
							
							//71070 --- New --- 2021 --- New (Observer)
							//Start:
							strtmp.append("Game number: ");
							strtmp.append(gameNumber);
							strtmp.append("The Winner is: ");
							strtmp.append(championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getStComp().getPersonName());
							propertyChanged(Controller.this,strtmp.toString(), gameNumber);
							//End
						}
						else {
							if(gameNumber > -1 && gameNumber < 4) {
								championsLeagueModel.getTheChampionship().getSemiFinalParticipantsList().add(championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getNdComp());
								championsLeagueView.getSemiFinalAndFinalParticipantsListTextFieldsToFill().get(View.MainView.Finals_Text_Fields_Index).setText(championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getNdComp().getPersonName());
								championsLeagueView.getSemiFinalAndFinalParticipantsListTextFieldsToFill().get(View.MainView.Finals_Text_Fields_Index).setDisable(true);							}
							else if(gameNumber > 3 && gameNumber < 6) {
								championsLeagueModel.getTheChampionship().getFinalParticipantsList().add(championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getNdComp());
								championsLeagueView.getSemiFinalAndFinalParticipantsListTextFieldsToFill().get(View.MainView.Finals_Text_Fields_Index).setText(championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getNdComp().getPersonName());
								championsLeagueView.getSemiFinalAndFinalParticipantsListTextFieldsToFill().get(View.MainView.Finals_Text_Fields_Index).setDisable(true);							}
							else if(gameNumber == 6){
								championsLeagueView.getSemiFinalAndFinalParticipantsListTextFieldsToFill().get(View.MainView.Finals_Text_Fields_Index).setText(championsLeagueModel.getTheChampionship().getFinalParticipantsList().get(1).getPersonName());
							}
							View.MainView.Finals_Text_Fields_Index++;
							
							//71070 --- New --- 2021 --- New (Observer)
							//Start:
							strtmp.append("Game number: ");
							strtmp.append(gameNumber);
							strtmp.append("The Winner is: ");
							strtmp.append(championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getNdComp().getPersonName());
							propertyChanged(Controller.this,strtmp.toString(), gameNumber);
							//End
						}
					} catch (RulesException e) {
						championsLeagueView.displayErrorMassage(e.getMessage()+" Keep tennis rules");
						tmp = true;

					}
					championsLeagueView.clearTennisStOpResult1Tf();
					championsLeagueView.clearTennisStOpResult2Tf();
					championsLeagueView.clearTennisStOpResult3Tf();
					championsLeagueView.clearTennisStOpResult4Tf();
					championsLeagueView.clearTennisStOpResult5Tf();

					championsLeagueView.clearTennisNdOpResult1Tf();
					championsLeagueView.clearTennisNdOpResult2Tf();
					championsLeagueView.clearTennisNdOpResult3Tf();
					championsLeagueView.clearTennisNdOpResult4Tf();
					championsLeagueView.clearTennisNdOpResult5Tf();

					championsLeagueView.hideTennisGameReStage();
				}
				while(tmp);
				if(gameNumber == 3)
					try {
						championsLeagueModel.getTheChampionship().startSemiFinualTourBuildUp("Tennis");
					} catch (CloneNotSupportedException e) {
						System.out.println(e.getMessage());
					}
				if(gameNumber == 5)
					championsLeagueModel.getTheChampionship().startFinalTourBuildUp("Tennis");
			}
		};
		championsLeagueView.addEventHandlerToTennisGameResultsSubmitButton(addEventHandlerToTennisGameResultsSubmitButton);
		//propertyChangeLikeSurfer 
		EventHandler<ActionEvent> addEventHandlerToBasketBallGameResultsSubmitButton = new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				StringBuffer strtmp = new StringBuffer();
				boolean tmp;
				Vector<Integer> stCompResults = new Vector<Integer>(5);
				Vector<Integer> ndCompResults = new Vector<Integer>(5);
				do {
					if(!championsLeagueView.getBasKetBallGameReStage().isShowing())
					{
						championsLeagueView.clearBasKetBallStOpResult1Tf();
						championsLeagueView.clearBasKetBallStOpResult2Tf();
						championsLeagueView.clearBasKetBallStOpResult3Tf();
						championsLeagueView.clearBasKetBallStOpResult4Tf();

						championsLeagueView.clearBasKetBallNdOpResult1Tf();
						championsLeagueView.clearBasKetBallNdOpResult2Tf();
						championsLeagueView.clearBasKetBallNdOpResult3Tf();
						championsLeagueView.clearBasKetBallNdOpResult4Tf();

						championsLeagueView.showBasKetBallGameReStage();
					}
					tmp = false;
					stCompResults.add(0, Integer.parseInt(championsLeagueView.getBasKetBallStOpResult1Tf()));
					ndCompResults.add(0, Integer.parseInt(championsLeagueView.getBasKetBallNdOpResult1Tf()));
					stCompResults.add(1, Integer.parseInt(championsLeagueView.getBasKetBallStOpResult2Tf()));
					ndCompResults.add(1, Integer.parseInt(championsLeagueView.getBasKetBallNdOpResult2Tf()));
					stCompResults.add(2, Integer.parseInt(championsLeagueView.getBasKetBallStOpResult3Tf()));
					ndCompResults.add(2, Integer.parseInt(championsLeagueView.getBasKetBallNdOpResult3Tf()));
					stCompResults.add(3, Integer.parseInt(championsLeagueView.getBasKetBallStOpResult4Tf()));
					ndCompResults.add(3, Integer.parseInt(championsLeagueView.getBasKetBallNdOpResult4Tf()));

					try {
						if(championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).isTheFirstCompWins(stCompResults, ndCompResults) == Rate.WINNER) {
							if(gameNumber > -1 && gameNumber < 4) {
								championsLeagueModel.getTheChampionship().getSemiFinalParticipantsList().add(championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getStComp());
								championsLeagueView.getSemiFinalAndFinalParticipantsListTextFieldsToFill().get(View.MainView.Finals_Text_Fields_Index).setText(championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getStComp().getPersonName());
								championsLeagueView.getSemiFinalAndFinalParticipantsListTextFieldsToFill().get(View.MainView.Finals_Text_Fields_Index).setDisable(true);							}
							else if(gameNumber > 3 && gameNumber < 6) {
								championsLeagueModel.getTheChampionship().getFinalParticipantsList().add(championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getStComp());
								championsLeagueView.getSemiFinalAndFinalParticipantsListTextFieldsToFill().get(View.MainView.Finals_Text_Fields_Index).setText(championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getStComp().getPersonName());
								championsLeagueView.getSemiFinalAndFinalParticipantsListTextFieldsToFill().get(View.MainView.Finals_Text_Fields_Index).setDisable(true);							}
							else if(gameNumber == 6){
								championsLeagueView.getSemiFinalAndFinalParticipantsListTextFieldsToFill().get(View.MainView.Finals_Text_Fields_Index).setText(championsLeagueModel.getTheChampionship().getFinalParticipantsList().get(0).getPersonName());
							}

							View.MainView.Finals_Text_Fields_Index++;
							
							//71070 --- New --- 2021 --- New (Observer)
							//Start:
							strtmp.append("Game number: " );
							strtmp.append(gameNumber);
							strtmp.append("The Winner is: ");
							strtmp.append(championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getStComp().getPersonName());
							propertyChanged(Controller.this,strtmp.toString(), gameNumber);
							//End
						}
						else {
							if(gameNumber > -1 && gameNumber < 4) {
								championsLeagueModel.getTheChampionship().getSemiFinalParticipantsList().add(championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getNdComp());
								championsLeagueView.getSemiFinalAndFinalParticipantsListTextFieldsToFill().get(View.MainView.Finals_Text_Fields_Index).setText(championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getNdComp().getPersonName());
								championsLeagueView.getSemiFinalAndFinalParticipantsListTextFieldsToFill().get(View.MainView.Finals_Text_Fields_Index).setDisable(true);							}
							else if(gameNumber > 3 && gameNumber < 6) {
								championsLeagueModel.getTheChampionship().getFinalParticipantsList().add(championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getNdComp());
								championsLeagueView.getSemiFinalAndFinalParticipantsListTextFieldsToFill().get(View.MainView.Finals_Text_Fields_Index).setText(championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getNdComp().getPersonName());
								championsLeagueView.getSemiFinalAndFinalParticipantsListTextFieldsToFill().get(View.MainView.Finals_Text_Fields_Index).setDisable(true);							}
							else if(gameNumber == 6){
								championsLeagueView.getSemiFinalAndFinalParticipantsListTextFieldsToFill().get(View.MainView.Finals_Text_Fields_Index).setText(championsLeagueModel.getTheChampionship().getFinalParticipantsList().get(1).getPersonName());
							}
							View.MainView.Finals_Text_Fields_Index++;
							
							//71070 --- New --- 2021 --- New (Observer)
							//Start:
							strtmp.append("Game number: " );
							strtmp.append(gameNumber);
							strtmp.append("The Winner is: ");
							strtmp.append(championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getNdComp().getPersonName());
							propertyChanged(Controller.this,strtmp.toString(), gameNumber);
							//End
						}
					} catch (RulesException e) {
						championsLeagueView.displayErrorMassage(e.getMessage() + " It must be a winner");
						tmp = true;
					}
					championsLeagueView.clearBasKetBallStOpResult1Tf();
					championsLeagueView.clearBasKetBallStOpResult2Tf();
					championsLeagueView.clearBasKetBallStOpResult3Tf();
					championsLeagueView.clearBasKetBallStOpResult4Tf();

					championsLeagueView.clearBasKetBallNdOpResult1Tf();
					championsLeagueView.clearBasKetBallNdOpResult2Tf();
					championsLeagueView.clearBasKetBallNdOpResult3Tf();
					championsLeagueView.clearBasKetBallNdOpResult4Tf();

					championsLeagueView.hideBasKetBallGameReStage();
				}
				while(tmp);
				if(gameNumber == 3)
					try {
						championsLeagueModel.getTheChampionship().startSemiFinualTourBuildUp("BasketBall");
					} catch (CloneNotSupportedException e) {
						System.out.println(e.getMessage());
					}
				if(gameNumber == 5)
					championsLeagueModel.getTheChampionship().startFinalTourBuildUp("BasketBall");
			}
		};
		championsLeagueView.addEventHandlerToBasketBallResultsSubmitButton(addEventHandlerToBasketBallGameResultsSubmitButton);
		//propertyChangeLikeSurfer 
		EventHandler<ActionEvent> addEventHandlerToPenaltyResultsSubmitButton = new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				StringBuffer strtmp = new StringBuffer();
				boolean tmp;
				Vector<Integer> stCompResults = new Vector<Integer>(5);
				Vector<Integer> ndCompResults = new Vector<Integer>(5);

				do {
					if (!championsLeagueView.getPenaltyStage().isShowing()) {
						championsLeagueView.showPenaltyStage();
					}
					stCompResults.add(0, Integer.parseInt(championsLeagueView.getPenaltyStOpResult1Cb()));
					ndCompResults.add(0, Integer.parseInt(championsLeagueView.getPenaltyNdOpResult1Cb()));
					stCompResults.add(1, Integer.parseInt(championsLeagueView.getPenaltyStOpResult2Cb()));
					ndCompResults.add(1, Integer.parseInt(championsLeagueView.getPenaltyNdOpResult2Cb()));
					stCompResults.add(2, Integer.parseInt(championsLeagueView.getPenaltyStOpResult3Cb()));
					ndCompResults.add(2, Integer.parseInt(championsLeagueView.getPenaltyNdOpResult3Cb()));
					stCompResults.add(3, Integer.parseInt(championsLeagueView.getPenaltyStOpResult4Cb()));
					ndCompResults.add(3, Integer.parseInt(championsLeagueView.getPenaltyNdOpResult4Cb()));
					stCompResults.add(4, Integer.parseInt(championsLeagueView.getPenaltyStOpResult5Cb()));
					ndCompResults.add(4, Integer.parseInt(championsLeagueView.getPenaltyNdOpResult5Cb()));
					tmp = false;
					try {
						if (championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).isTheFirstCompWins(stCompResults, ndCompResults) == Rate.WINNER) {
							if (gameNumber > -1 && gameNumber < 4) {
								championsLeagueModel.getTheChampionship().getSemiFinalParticipantsList().add(championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getStComp());
								championsLeagueView.getSemiFinalAndFinalParticipantsListTextFieldsToFill().get(View.MainView.Finals_Text_Fields_Index).setText(championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getStComp().getPersonName());
								championsLeagueView.getSemiFinalAndFinalParticipantsListTextFieldsToFill().get(View.MainView.Finals_Text_Fields_Index).setDisable(true);							} else if (gameNumber > 3 && gameNumber < 6) {
								championsLeagueModel.getTheChampionship().getFinalParticipantsList().add(championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getStComp());
								championsLeagueView.getSemiFinalAndFinalParticipantsListTextFieldsToFill().get(View.MainView.Finals_Text_Fields_Index).setText(championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getStComp().getPersonName());
								championsLeagueView.getSemiFinalAndFinalParticipantsListTextFieldsToFill().get(View.MainView.Finals_Text_Fields_Index).setDisable(true);							} else if (gameNumber == 6) {
								championsLeagueView.getSemiFinalAndFinalParticipantsListTextFieldsToFill().get(View.MainView.Finals_Text_Fields_Index).setText(championsLeagueModel.getTheChampionship().getFinalParticipantsList().get(0).getPersonName());
							}

							View.MainView.Finals_Text_Fields_Index++;
							
							//71070 --- New --- 2021 --- New (Observer)
							//Start:
							strtmp.append("Game number: ");
							strtmp.append(gameNumber);
							strtmp.append("The Winner is: ");
							strtmp.append(championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getStComp().getPersonName());
							propertyChanged(Controller.this,strtmp.toString(), gameNumber);
							//End
						} 
						else {
							if (gameNumber > -1 && gameNumber < 4) {
								championsLeagueModel.getTheChampionship().getSemiFinalParticipantsList().add(championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getNdComp());
								championsLeagueView.getSemiFinalAndFinalParticipantsListTextFieldsToFill().get(View.MainView.Finals_Text_Fields_Index).setText(championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getNdComp().getPersonName());
								championsLeagueView.getSemiFinalAndFinalParticipantsListTextFieldsToFill().get(View.MainView.Finals_Text_Fields_Index).setDisable(true);							} else if (gameNumber > 3 && gameNumber < 6) {
								championsLeagueModel.getTheChampionship().getFinalParticipantsList().add(championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getNdComp());
								championsLeagueView.getSemiFinalAndFinalParticipantsListTextFieldsToFill().get(View.MainView.Finals_Text_Fields_Index).setText(championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getNdComp().getPersonName());
								championsLeagueView.getSemiFinalAndFinalParticipantsListTextFieldsToFill().get(View.MainView.Finals_Text_Fields_Index).setDisable(true);							} else if (gameNumber == 6) {
								championsLeagueView.getSemiFinalAndFinalParticipantsListTextFieldsToFill().get(View.MainView.Finals_Text_Fields_Index).setText(championsLeagueModel.getTheChampionship().getFinalParticipantsList().get(1).getPersonName());
							}
							View.MainView.Finals_Text_Fields_Index++;
							
							//71070 --- New --- 2021 --- New (Observer)
							//Start:
							strtmp.append("Game number: ");
							strtmp.append(gameNumber);
							strtmp.append("The Winner is: ");
							strtmp.append(championsLeagueModel.getTheChampionship().getTournament().get(gameNumber).getNdComp().getPersonName());
							propertyChanged(Controller.this,strtmp.toString(), gameNumber);
							//End
						}
					}
					catch (RulesException e) {
						championsLeagueView.displayErrorMassage(e.getMessage() + " It must be a winner");
						tmp = true;
					}
					championsLeagueView.clearPenaltyStOpResult1Cb();
					championsLeagueView.clearPenaltyStOpResult2Cb();
					championsLeagueView.clearPenaltyStOpResult3Cb();
					championsLeagueView.clearPenaltyStOpResult4Cb();
					championsLeagueView.clearPenaltyStOpResult5Cb();

					championsLeagueView.clearPenaltyNdOpResult1Cb();
					championsLeagueView.clearPenaltyNdOpResult2Cb();
					championsLeagueView.clearPenaltyNdOpResult3Cb();
					championsLeagueView.clearPenaltyNdOpResult4Cb();
					championsLeagueView.clearPenaltyNdOpResult5Cb();

					championsLeagueView.hidePenaltyStage();
				} while (tmp);
				if(gameNumber == 3)
					try {
						championsLeagueModel.getTheChampionship().startSemiFinualTourBuildUp("Soccer");
					} catch (CloneNotSupportedException e) {
						System.out.println(e.getMessage());
					}
				if(gameNumber == 5)
					championsLeagueModel.getTheChampionship().startFinalTourBuildUp("Soccer");
			}

		};
		championsLeagueView.addEventHandlerToPenaltysResultsSubmitButton(addEventHandlerToPenaltyResultsSubmitButton);
		
		
	}
	//71070 --- New --- 2021 --- New (Observer)
	//Start:
	private void subscribeToController(AuthorizedPress aP)
	{
		this.subscribe(aP);
	}
	//End....
}
