//71070 --- New --- 2021 --- New (Proxy)
//Start:
package Inteface;

public interface Authorizable {
	boolean isAuthorized();
}
//End.