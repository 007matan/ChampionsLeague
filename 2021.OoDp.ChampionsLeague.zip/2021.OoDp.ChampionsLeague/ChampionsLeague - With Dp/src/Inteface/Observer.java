//71070 --- New --- 2021 --- New (Observer)
//Start:
package Inteface;
import Model.*;

public interface Observer<T> {
	void handle(PropertyChangedEventArgs<T> args);
}
//End.