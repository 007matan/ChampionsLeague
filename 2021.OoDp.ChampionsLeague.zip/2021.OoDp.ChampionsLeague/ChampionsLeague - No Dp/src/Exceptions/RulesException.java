package Exceptions;

public class RulesException extends SystemException {
	public RulesException(int index) {
		super("The value" +index+  " are not valid for options of results ");
	}
}
