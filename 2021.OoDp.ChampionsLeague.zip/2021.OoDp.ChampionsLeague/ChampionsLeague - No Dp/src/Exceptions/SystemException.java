package Exceptions;

public class SystemException extends Exception{
	public SystemException(String msg) {
		super(msg);
	}

}
