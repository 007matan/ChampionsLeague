package Exceptions;


public class RegistrationException extends SystemException {
	public RegistrationException(int index) {
		super("The value " +index+  " are not valid for ID number");
	}
}
