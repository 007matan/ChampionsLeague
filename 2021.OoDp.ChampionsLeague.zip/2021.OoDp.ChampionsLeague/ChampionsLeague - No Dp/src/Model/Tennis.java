package Model;

import java.util.Vector;

import Exceptions.RulesException;

public class Tennis extends Game {

	public Tennis(Person stComp, Person ndComp) {
		super(stComp, ndComp, TENNIS_NUMBER_OF_SETS);
	}
	
	public boolean equals (Game other) {
		if(!(other instanceof Tennis))
			return false;
		return true;
	}

	@Override
	public Rate isTheFirstCompWins(Vector<Integer> stCompResults, Vector<Integer> ndCompResults) throws RulesException {
		int stSetCounter = 0, ndSetCounter = 0;
		int stCompScore = 0, ndCompScore = 0;
		for(int i = 0; i < stCompResults.size(); i++) {
			stCompScore = stCompResults.get(i);
			ndCompScore = ndCompResults.get(i);
			if(((stCompScore - ndCompScore) > -3 ) && (stCompScore - ndCompScore) < 1 )
				throw new RulesException(ndCompScore);
			if(((stCompScore - ndCompScore) < 3 ) && (stCompScore - ndCompScore) > -1 )
				throw new RulesException(ndCompScore);
			if(stCompScore > ndCompScore)
				stSetCounter++;
			else if(stCompScore < ndCompScore)
				ndSetCounter++;
			else
				throw new RulesException(stCompScore);
			
		}
		if(stSetCounter > ndSetCounter)
			return Rate.WINNER;
		return Rate.LOOSER;
	}
}
