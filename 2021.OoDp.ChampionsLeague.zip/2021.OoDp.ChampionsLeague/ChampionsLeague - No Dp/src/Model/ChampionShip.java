package Model;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Vector;

import Exceptions.RegistrationException;

public class ChampionShip {

	public final static int NUMBER_OF_PARTICIPENTS = 8;
	public final static int NUMBER_OF_FIRST_ROUND_GAMES = 4;
	public final static int NUMBER_OF_SECOND_ROUND_GAMES = 2;
	public final static int NUMBER_OF_FINAL_ROUND_GAME = 1;


	private ArrayList <Game> tournament;

	private ArrayList <Person> participantsList;

	private ArrayList <Person> semiFinalParticipantsList;

	private ArrayList <Person> finalParticipantsList;

	public ChampionShip() {
		this.tournament = null;
		this.participantsList = new ArrayList <Person>(8);
		this.semiFinalParticipantsList = new ArrayList <Person>(4);
		this.finalParticipantsList =  new ArrayList<Person>(2);
	}
	
	

	public ArrayList<Person> getParticipantsList() {
		return participantsList;
	}
	
	public ArrayList<Person> getSemiFinalParticipantsList() {
		return semiFinalParticipantsList;
	}

	public ArrayList<Game> getTournament() {
		return tournament;
	}
	

	public ArrayList<Person> getFinalParticipantsList() {
		return finalParticipantsList;
	}

    //Add Person - 
	//The function gets: String (name) , int (id).
	//The function will create a new person, if the person does not exist (by id), and if is not 8 participants already.  
	public void addPerson(String name, int id) throws InputMismatchException,RegistrationException, Exception{
		if(participantsList.size() < 8) {
			boolean found = false;
			Person tmpPerson = new Person(name, id);
			for(int i = 0; i < participantsList.size(); i++) {
				if(tmpPerson.equals(participantsList.get(i))) {
					found = true;
					break;
				}
			}
			if(!found) {
				participantsList.add(tmpPerson);
			}
			else
				throw new Exception("There are a participent like " + tmpPerson.getId() + " which have same Id number");
		}
		else {
			throw new Exception("There are already 8 participants");
		}

	}
    //Start The Tour - 
	//The function gets: String (game).
	//The function will create the Quarter final. 
	public void startTheTour(String game) {
		int participentsIndex;
		ArrayList<Game> firstRound = new ArrayList<Game>(NUMBER_OF_FIRST_ROUND_GAMES);
		if(getParticipantsList().size() == NUMBER_OF_PARTICIPENTS) {
			if(game == "Tennis") {
				participentsIndex = 0;
				for(int i = 0; i < NUMBER_OF_FIRST_ROUND_GAMES; i++, participentsIndex++) {
					firstRound.add(new Tennis(participantsList.get(participentsIndex), participantsList.get(++participentsIndex)));
				}
			}
			else if(game == "Soccer") {
				participentsIndex = 0;
				for(int i = 0; i < NUMBER_OF_FIRST_ROUND_GAMES; i++, participentsIndex++) {
					firstRound.add(new Soccer(participantsList.get(participentsIndex), participantsList.get(++participentsIndex)));
				}
			}
			else if(game == "BasketBall") {
				participentsIndex = 0;
				for(int i = 0; i < NUMBER_OF_FIRST_ROUND_GAMES; i++, participentsIndex++) {
					firstRound.add(new BasketBall(participantsList.get(participentsIndex), participantsList.get(++participentsIndex)));
				}
			}
		}
		tournament = firstRound;
	}
    //Start The Semi Final Tour - 
	//The function gets: String (game).
	//The function will create the Semi Final.
	public void startSemiFinualTourBuildUp(String name) {
		if(tournament.size() < 6) {
			ArrayList<Game> semiFinal = new ArrayList<Game>(2);
			Game stGame = null, ndGame = null;
			if(name == "Tennis") {
				stGame = new Tennis(semiFinalParticipantsList.get(0), semiFinalParticipantsList.get(1));
				ndGame = new  Tennis(semiFinalParticipantsList.get(2), semiFinalParticipantsList.get(3));
			}
			else if(name == "Soccer") {
				stGame = new Soccer(semiFinalParticipantsList.get(0), semiFinalParticipantsList.get(1));
				ndGame = new  Soccer(semiFinalParticipantsList.get(2), semiFinalParticipantsList.get(3));
			}
			else if(name == "BasketBall") {
				stGame = new BasketBall(semiFinalParticipantsList.get(0), semiFinalParticipantsList.get(1));
				ndGame = new  BasketBall(semiFinalParticipantsList.get(2), semiFinalParticipantsList.get(3));
			}
			semiFinal.add(stGame);
			semiFinal.add(ndGame);
			tournament.addAll(semiFinal);
		}
	}
    //Start The Final Tour - 
	//The function gets: String (game).
	//The function will create the Final.
	public void startFinalTourBuildUp(String name) {
		if(tournament.size() == 6) {
			Game game = null;
			if(name == "Tennis") {
				game = new Tennis(finalParticipantsList.get(0), finalParticipantsList.get(1));
			}
			else if(name == "Soccer") {
				game = new Soccer(finalParticipantsList.get(0), finalParticipantsList.get(1));
			}
			else if(name == "BasketBall") {
				game = new BasketBall(finalParticipantsList.get(0), finalParticipantsList.get(1));
			}
			tournament.add(game);
		}
	}	
}
