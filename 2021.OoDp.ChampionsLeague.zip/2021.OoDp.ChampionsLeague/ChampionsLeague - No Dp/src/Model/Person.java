package Model;

import java.util.InputMismatchException;

import Exceptions.*;

public class Person {

	private String personName; 
	private int id;
	
	public Person(String name, int id) throws InputMismatchException, RegistrationException {
		setPersonName(name);
		setId(id);
	}

	public String getPersonName() {
		return personName;
	}
	

	public void setPersonName(String personName) {
		this.personName = personName;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) throws RegistrationException, InputMismatchException {
		if(!correctId(id))
			throw new RegistrationException(id);
		this.id = id;
	}
	
	public boolean equals(Person p) {
		if(getId() == p.getId())
			return true;
		return false;
	}
	
	public boolean correctId(int id) {
		//return true;
		///*
		int sum = 0;
		boolean odd = true;
		int temp = 0;
		for (int i = 0; i < 9; i++)
		{
			odd = !odd;
			temp = (id % 10) * ((odd ? 1 : 0) + 1);
			sum += temp % 10;
			if (temp > 10)
				sum++;
			id /= 10;
		}
		if (sum % 10 == 0)
			return true;
		else
			return false;
		//	*/
	}
	
}
