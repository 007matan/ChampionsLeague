package Model;

import java.util.Vector;

import Exceptions.RulesException;
import Inteface.Decisionalble.Rate;

public class BasketBall extends Game {
	
	public BasketBall(Person stComp, Person ndComp) {
		super(stComp, ndComp, BASKETBALL_NUMBER_OF_SETS);
	}

	public boolean equals (Game other) {
		if(!(other instanceof BasketBall))
			return false;
		return true;
	}

	@Override
	public Rate isTheFirstCompWins(Vector<Integer> stCompResults, Vector<Integer> ndCompResults) throws RulesException {
		int stCompScore = 0, ndCompScore = 0;
		for(int i = 0; i < stCompResults.size(); i++) {
			stCompScore+=stCompResults.get(i);
			ndCompScore+=ndCompResults.get(i);
		}
		if(stCompScore > ndCompScore)
			return Rate.WINNER;
		else if(stCompScore < ndCompScore)
			return Rate.LOOSER;
		else
		{
			throw  new RulesException(stCompScore);
		}
	}
}
