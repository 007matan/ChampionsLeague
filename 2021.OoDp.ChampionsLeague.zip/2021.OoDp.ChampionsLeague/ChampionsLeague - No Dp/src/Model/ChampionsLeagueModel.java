package Model;

import java.util.InputMismatchException;

public class ChampionsLeagueModel {
	private static ChampionShip theChampionship;
	
	public ChampionsLeagueModel() {
		theChampionship = new ChampionShip();
	}
	
	public int addParticipant(String name, int id) throws InputMismatchException, Exception {
		theChampionship.addPerson(name, id);
		return theChampionship.getParticipantsList().size();
	}
	public void startTheTour(String game) {
		theChampionship.startTheTour(game);
	}

	public static ChampionShip getTheChampionship() {
		return theChampionship;
	}
	

}
