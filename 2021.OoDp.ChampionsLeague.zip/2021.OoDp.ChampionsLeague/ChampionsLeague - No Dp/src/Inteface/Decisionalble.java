package Inteface;

import java.util.Vector;

import Exceptions.RulesException;

public interface Decisionalble {
	public enum Rate{ WINNER, LOOSER};

	public Rate isTheFirstCompWins(Vector<Integer> stCompResults, Vector<Integer> ndCompResults) throws RulesException;
}
